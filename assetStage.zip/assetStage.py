bl_info = {
    "name": "Asset Stage",
    "author": "CGjuice", 
    "version": (1, 1),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Asset Stage",
    "description": "Cyclorama, Lighting, Wireframe, AO, and Smart Rendering.",
    "category": "Lighting",  
    "doc_url": "https://github.com/CGjuice/assetStage",
}

import bpy
import math
import bmesh
import os
import datetime
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
from math import sin, cos, radians

# ==============================================================================
#   GLOBALS & CONSTANTS
# ==============================================================================

TAG_KEY = "Studio_Asset"
AO_MAT_NAME = "AO_Procedural_Mat"

# ==============================================================================
#   HELPER FUNCTIONS (GENERAL)
# ==============================================================================

def get_object_scale_factor(obj):
    if not obj: return 1.0
    dims = obj.dimensions
    max_dim = max(dims.x, dims.y, dims.z)
    if max_dim < 2.0: return 1.0
    return max_dim / 2.0

def update_ao_shader(self, context):
    """Updates node settings on the Global Mat AND the Active Unique Mat"""
    
    def apply_to_tree(tree):
        if not tree: return
        nodes = tree.nodes
        
        ao_node = nodes.get("AO_Node")
        mix_node = nodes.get("AO_Color_Mix")
        gamma_node = nodes.get("AO_Gamma")
        bsdf_node = nodes.get("AO_Principled")

        if ao_node:
            ao_node.inputs['Distance'].default_value = self.ao_distance
            ao_node.inside = self.ao_inside

        if mix_node:
            if hasattr(mix_node.inputs['A'], 'default_value'): 
                mix_node.inputs['A'].default_value = self.color_crevice 
                mix_node.inputs['B'].default_value = self.color_surface
            else:
                mix_node.inputs[6].default_value = self.color_crevice 
                mix_node.inputs[7].default_value = self.color_surface

        if gamma_node:
            gamma_node.inputs['Gamma'].default_value = self.ao_contrast

        if bsdf_node:
            bsdf_node.inputs['Roughness'].default_value = self.roughness

    obj = context.active_object
    active_mat = None
    if obj and obj.type == 'MESH' and obj.material_slots:
        if obj.material_slots[0].link == 'OBJECT':
            active_mat = obj.material_slots[0].material
            if active_mat and active_mat.use_nodes:
                apply_to_tree(active_mat.node_tree)

    global_mat = bpy.data.materials.get(AO_MAT_NAME)
    if global_mat and global_mat != active_mat:
        apply_to_tree(global_mat.node_tree)


# ==============================================================================
#   HELPER FUNCTIONS (MATERIAL TOOLS)
# ==============================================================================

def ensure_unique_material(obj):
    """Auto-converts material to unique Object-Linked copy if currently Data-Linked"""
    if not obj or not obj.material_slots: return None
    slot = obj.material_slots[0]
    
    if slot.link == 'DATA':
         if not slot.material: return None
         new_mat = slot.material.copy()
         new_mat.name = f"{slot.material.name}_Tweak"
         slot.link = 'OBJECT'
         slot.material = new_mat
         return new_mat
         
    return slot.material

def get_output_node(mat):
    if not mat or not mat.node_tree: return None
    for node in mat.node_tree.nodes:
        if node.type == 'OUTPUT_MATERIAL':
            return node
    return None

def trace_downstream_bsdf(node, depth=0, max_depth=5):
    if not node: return None
    if node.type == 'BSDF_PRINCIPLED': return node
    if depth >= max_depth: return None
    for output in node.outputs:
        for link in output.links:
            found = trace_downstream_bsdf(link.to_node, depth + 1, max_depth)
            if found: return found
    return None

def get_principled(mat):
    if not mat or not mat.node_tree: return None
    out = get_output_node(mat)
    driving_node = None
    if out and out.inputs['Surface'].links:
        driving_node = out.inputs['Surface'].links[0].from_node
    if driving_node and driving_node.type == 'BSDF_PRINCIPLED': return driving_node
    if mat.node_tree.nodes.active and mat.node_tree.nodes.active.type == 'BSDF_PRINCIPLED':
        return mat.node_tree.nodes.active
    if driving_node:
        found_bsdf = trace_downstream_bsdf(driving_node)
        if found_bsdf: return found_bsdf
    for node in mat.node_tree.nodes:
        if node.type == 'BSDF_PRINCIPLED': return node
    return None

def get_linked_node(node, input_name):
    if input_name not in node.inputs: return None, None
    if not node.inputs[input_name].links: return None, None
    link = node.inputs[input_name].links[0]
    return link.from_node, link

def get_image_name(node):
    if not node: return ""
    if node.type == 'TEX_IMAGE' and node.image: return node.image.name
    return node.name

def is_data_input(input_name):
    return input_name in {'Roughness', 'Metallic', 'Specular', 'Specular IOR Level', 'Normal', 'Displacement', 'Alpha', 'Transmission', 'Clearcoat'}

def fix_texture_colorspace(node):
    if node.type == 'TEX_IMAGE' and node.image:
        if node.image.colorspace_settings.name != 'Non-Color':
            try:
                node.image.colorspace_settings.name = 'Non-Color'
                return True
            except: pass 
    return False

def force_disable_solo(context):
    """Ensures no material is in Solo Mode before rendering"""
    for obj in context.scene.objects:
        if obj.type == 'MESH' and obj.material_slots:
            for slot in obj.material_slots:
                mat = slot.material
                if mat and mat.node_tree:
                    out = get_output_node(mat)
                    bsdf = get_principled(mat)
                    if out and bsdf:
                        if out.inputs['Surface'].links:
                            link = out.inputs['Surface'].links[0]
                            if link.from_node != bsdf and link.from_node.type != 'MIX_SHADER':
                                mat.node_tree.links.new(bsdf.outputs[0], out.inputs['Surface'])

def update_sss(self, context):
    """Updates SSS settings on the active Unique Material (Blender 4.0+)"""
    obj = context.active_object
    if not obj or not obj.active_material: return
    
    bsdf = get_principled(obj.active_material) 
    if not bsdf: return

    if 'Subsurface Weight' in bsdf.inputs:
        bsdf.inputs['Subsurface Weight'].default_value = 1.0
    elif 'Subsurface' in bsdf.inputs: 
        bsdf.inputs['Subsurface'].default_value = 1.0

    if 'Subsurface Scale' in bsdf.inputs:
        bsdf.inputs['Subsurface Scale'].default_value = self.sss_scale

    if 'Subsurface Radius' in bsdf.inputs:
        c = self.sss_radius_color
        bsdf.inputs['Subsurface Radius'].default_value = (c[0], c[1], c[2])


# ==============================================================================
#   HELPER FUNCTIONS (WEATHERING / GRUNGE)
# ==============================================================================

def ensure_weathering_group():
    group_name = "Pro_Weathering_FX" 
    if group_name in bpy.data.node_groups:
        return bpy.data.node_groups[group_name]
    
    ng = bpy.data.node_groups.new(name=group_name, type='ShaderNodeTree')
    
    try:
        ng.interface.new_socket("Base Color", in_out='INPUT', socket_type='NodeSocketColor')
        ng.interface.new_socket("Dirt Color", in_out='INPUT', socket_type='NodeSocketColor')
        ng.interface.new_socket("Dirt Amount", in_out='INPUT', socket_type='NodeSocketFloat')
        ng.interface.new_socket("Dirt Spread", in_out='INPUT', socket_type='NodeSocketFloat')
        ng.interface.new_socket("Dirt Texture", in_out='INPUT', socket_type='NodeSocketFloat')
        ng.interface.new_socket("Global Scale", in_out='INPUT', socket_type='NodeSocketFloat')
        ng.interface.new_socket("Breakup Coverage", in_out='INPUT', socket_type='NodeSocketFloat')
        ng.interface.new_socket("Breakup Scale", in_out='INPUT', socket_type='NodeSocketFloat')
        ng.interface.new_socket("Breakup Contrast", in_out='INPUT', socket_type='NodeSocketFloat')
        ng.interface.new_socket("Edge Amount", in_out='INPUT', socket_type='NodeSocketFloat')
        ng.interface.new_socket("Edge Sense", in_out='INPUT', socket_type='NodeSocketFloat')
        ng.interface.new_socket("Bump Influence", in_out='INPUT', socket_type='NodeSocketFloat')
        
        ng.interface.new_socket("Result Color", in_out='OUTPUT', socket_type='NodeSocketColor')
        ng.interface.new_socket("Normal", in_out='OUTPUT', socket_type='NodeSocketVector')
    except:
        ng.inputs.new('NodeSocketColor', "Base Color")
        ng.inputs.new('NodeSocketColor', "Dirt Color")
        ng.inputs.new('NodeSocketFloat', "Dirt Amount")
        ng.inputs.new('NodeSocketFloat', "Dirt Spread")
        ng.inputs.new('NodeSocketFloat', "Dirt Texture")
        ng.inputs.new('NodeSocketFloat', "Global Scale")
        ng.inputs.new('NodeSocketFloat', "Breakup Coverage")
        ng.inputs.new('NodeSocketFloat', "Breakup Scale")
        ng.inputs.new('NodeSocketFloat', "Breakup Contrast")
        ng.inputs.new('NodeSocketFloat', "Edge Amount")
        ng.inputs.new('NodeSocketFloat', "Edge Sense")
        ng.inputs.new('NodeSocketFloat', "Bump Influence")
        ng.outputs.new('NodeSocketColor', "Result Color")
        ng.outputs.new('NodeSocketVector', "Normal")

    nodes = ng.nodes
    links = ng.links
    
    node_in = nodes.new('NodeGroupInput')
    node_in.location = (-1600, 0)
    node_out = nodes.new('NodeGroupOutput')
    node_out.location = (1000, 0)

    coord_mask = nodes.new('ShaderNodeTexCoord')
    coord_mask.location = (-1400, 600)
    noise_mask = nodes.new('ShaderNodeTexNoise')
    noise_mask.location = (-1200, 600)
    noise_mask.inputs['Detail'].default_value = 2.0
    noise_mask.inputs['Roughness'].default_value = 0.5
    
    links.new(coord_mask.outputs['Object'], noise_mask.inputs['Vector'])
    links.new(node_in.outputs['Breakup Scale'], noise_mask.inputs['Scale'])
    
    mask_range = nodes.new('ShaderNodeMapRange')
    mask_range.location = (-1000, 600)
    mask_range.clamp = True
    links.new(node_in.outputs['Breakup Coverage'], mask_range.inputs['From Min'])
    
    max_calc = nodes.new('ShaderNodeMath')
    max_calc.operation = 'ADD'
    max_calc.location = (-1200, 450)
    links.new(node_in.outputs['Breakup Coverage'], max_calc.inputs[0])
    
    inv_cont = nodes.new('ShaderNodeMath')
    inv_cont.operation = 'SUBTRACT'
    inv_cont.inputs[0].default_value = 1.0
    inv_cont.location = (-1350, 400)
    links.new(node_in.outputs['Breakup Contrast'], inv_cont.inputs[1])
    links.new(inv_cont.outputs[0], max_calc.inputs[1])
    
    links.new(noise_mask.outputs['Fac'], mask_range.inputs['Value'])
    links.new(max_calc.outputs[0], mask_range.inputs['From Max'])

    coord = nodes.new('ShaderNodeTexCoord')
    coord.location = (-1000, 200)
    noise = nodes.new('ShaderNodeTexNoise')
    noise.location = (-800, 200)
    noise.inputs['Roughness'].default_value = 0.7
    noise.inputs['Detail'].default_value = 5.0
    links.new(coord.outputs['Object'], noise.inputs['Vector'])
    
    scale_math = nodes.new('ShaderNodeMath')
    scale_math.operation = 'DIVIDE'
    scale_math.inputs[0].default_value = 10.0
    scale_math.location = (-1000, 100)
    links.new(node_in.outputs['Global Scale'], scale_math.inputs[1])
    links.new(scale_math.outputs[0], noise.inputs['Scale'])

    ao = nodes.new('ShaderNodeAmbientOcclusion')
    ao.location = (-800, 0)
    links.new(node_in.outputs['Global Scale'], ao.inputs['Distance'])
    
    spread_mult = nodes.new('ShaderNodeMath')
    spread_mult.operation = 'MULTIPLY'
    spread_mult.location = (-600, -100)
    spread_sub = nodes.new('ShaderNodeMath')
    spread_sub.operation = 'SUBTRACT'
    spread_sub.inputs[0].default_value = 5.0
    spread_sub.location = (-800, -100)
    links.new(node_in.outputs['Dirt Spread'], spread_mult.inputs[0])
    links.new(spread_sub.outputs[0], spread_mult.inputs[1]) 
    
    dirt_pow = nodes.new('ShaderNodeMath')
    dirt_pow.operation = 'POWER'
    dirt_pow.location = (-400, 0)
    links.new(ao.outputs['Color'], dirt_pow.inputs[0])
    links.new(spread_mult.outputs[0], dirt_pow.inputs[1])

    mix_noise = nodes.new('ShaderNodeMix')
    mix_noise.data_type = 'RGBA'
    mix_noise.blend_type = 'OVERLAY'
    mix_noise.location = (-200, 100)
    links.new(node_in.outputs['Dirt Texture'], mix_noise.inputs['Factor'])
    links.new(dirt_pow.outputs[0], mix_noise.inputs['A'])
    links.new(noise.outputs['Fac'], mix_noise.inputs['B'])
    
    apply_breakup = nodes.new('ShaderNodeMath')
    apply_breakup.operation = 'MULTIPLY'
    apply_breakup.location = (0, 300)
    links.new(mix_noise.outputs['Result'], apply_breakup.inputs[0])
    links.new(mask_range.outputs['Result'], apply_breakup.inputs[1])

    mix_dirt = nodes.new('ShaderNodeMix')
    mix_dirt.data_type = 'RGBA'
    mix_dirt.blend_type = 'MULTIPLY'
    mix_dirt.location = (200, 100)
    
    final_dirt_fac = nodes.new('ShaderNodeMath')
    final_dirt_fac.operation = 'MULTIPLY'
    final_dirt_fac.location = (0, 150)
    links.new(apply_breakup.outputs[0], final_dirt_fac.inputs[0])
    links.new(node_in.outputs['Dirt Amount'], final_dirt_fac.inputs[1])
    
    links.new(final_dirt_fac.outputs[0], mix_dirt.inputs['Factor'])
    links.new(node_in.outputs['Base Color'], mix_dirt.inputs['A'])
    links.new(node_in.outputs['Dirt Color'], mix_dirt.inputs['B'])

    geo = nodes.new('ShaderNodeNewGeometry')
    geo.location = (-600, -400)
    
    sub = nodes.new('ShaderNodeMath')
    sub.operation = 'SUBTRACT'
    sub.inputs[1].default_value = 0.5
    sub.location = (-400, -400)
    
    mult_sense = nodes.new('ShaderNodeMath')
    mult_sense.operation = 'MULTIPLY'
    mult_sense.location = (-200, -400)
    
    clamp = nodes.new('ShaderNodeMath')
    clamp.operation = 'MAXIMUM'
    clamp.inputs[1].default_value = 0.0
    clamp.location = (0, -400)
    
    mix_edge = nodes.new('ShaderNodeMix')
    mix_edge.data_type = 'RGBA'
    mix_edge.blend_type = 'SCREEN'
    mix_edge.inputs['B'].default_value = (0.95, 0.95, 1.0, 1.0)
    mix_edge.location = (400, 100)
    
    links.new(geo.outputs['Pointiness'], sub.inputs[0])
    links.new(sub.outputs[0], mult_sense.inputs[0])
    links.new(node_in.outputs['Edge Sense'], mult_sense.inputs[1])
    links.new(mult_sense.outputs[0], clamp.inputs[0])
    
    edge_mask = nodes.new('ShaderNodeMath')
    edge_mask.operation = 'ADD'
    edge_mask.inputs[1].default_value = 0.2
    edge_mask.location = (-200, 500)
    links.new(mask_range.outputs['Result'], edge_mask.inputs[0])
    
    edge_str = nodes.new('ShaderNodeMath')
    edge_str.operation = 'MULTIPLY'
    edge_str.location = (200, -400)
    links.new(clamp.outputs[0], edge_str.inputs[0])
    
    edge_final_fac = nodes.new('ShaderNodeMath')
    edge_final_fac.operation = 'MULTIPLY' 
    edge_final_fac.location = (200, -300)
    links.new(node_in.outputs['Edge Amount'], edge_final_fac.inputs[0])
    links.new(edge_mask.outputs[0], edge_final_fac.inputs[1])
    links.new(edge_final_fac.outputs[0], edge_str.inputs[1])
    
    links.new(mix_dirt.outputs['Result'], mix_edge.inputs['A'])
    links.new(edge_str.outputs[0], mix_edge.inputs['Factor'])

    bw = nodes.new('ShaderNodeRGBToBW')
    bw.location = (600, -100)
    bump = nodes.new('ShaderNodeBump')
    bump.location = (800, -100)
    bump.invert = True 
    
    links.new(mix_edge.outputs['Result'], bw.inputs['Color'])
    links.new(bw.outputs['Val'], bump.inputs['Height'])
    links.new(node_in.outputs['Bump Influence'], bump.inputs['Strength'])
    
    links.new(mix_edge.outputs['Result'], node_out.inputs['Result Color'])
    links.new(bump.outputs['Normal'], node_out.inputs['Normal'])
    
    return ng

def update_weathering_values(self, context):
    """Updates the Active Object's Weathering Node with Scene Props"""
    obj = context.active_object
    if not obj or not obj.active_material: return
    
    mat = obj.active_material
    node = None
    for n in mat.node_tree.nodes:
        if n.type == 'GROUP' and n.node_tree and "Pro_Weathering_FX" in n.node_tree.name:
            node = n
            break
    
    if not node: return
    inputs = node.inputs
    props = context.scene.weathering_props
    
    if inputs.get("Dirt Amount"): inputs["Dirt Amount"].default_value = props.w_dirt_amount
    if inputs.get("Dirt Color"): inputs["Dirt Color"].default_value = props.w_dirt_color
    if inputs.get("Dirt Spread"): inputs["Dirt Spread"].default_value = props.w_dirt_spread
    if inputs.get("Dirt Texture"): inputs["Dirt Texture"].default_value = props.w_dirt_texture
    if inputs.get("Global Scale"): inputs["Global Scale"].default_value = props.w_global_scale
    
    if inputs.get("Breakup Coverage"): inputs["Breakup Coverage"].default_value = props.w_breakup_cov
    if inputs.get("Breakup Scale"): inputs["Breakup Scale"].default_value = props.w_breakup_scale
    if inputs.get("Breakup Contrast"): inputs["Breakup Contrast"].default_value = props.w_breakup_cont
    
    if inputs.get("Edge Amount"): inputs["Edge Amount"].default_value = props.w_edge_amount
    if inputs.get("Edge Sense"):  inputs["Edge Sense"].default_value = props.w_edge_sense * 10.0
    if inputs.get("Bump Influence"): inputs["Bump Influence"].default_value = props.w_bump_val


# ==============================================================================
#   HELPER FUNCTIONS (SMART RENDER LOGIC)
# ==============================================================================

def clean_string(input_str):
    if not input_str:
        return ""
    s = input_str.replace(" ", "_").replace("-", "_")
    invalid_chars = '<>:"/\|?*().'
    for char in invalid_chars:
        s = s.replace(char, "")
    return s

def generate_render_filename(scene, props):
    parts = []
    
    if props.use_date:
        parts.append(datetime.datetime.now().strftime("%Y_%m_%d"))

    if props.use_filename:
        if bpy.data.filepath:
            fname = os.path.splitext(os.path.basename(bpy.data.filepath))[0]
            parts.append(clean_string(fname))
        else:
            parts.append("Unsaved_File")

    if props.use_scene:
        parts.append(clean_string(scene.name))
        
    if props.use_camera:
        if scene.camera:
            parts.append(clean_string(scene.camera.name))
        else:
            parts.append("NoCam")

    if props.use_custom and props.custom_text:
        parts.append(clean_string(props.custom_text))

    base_name = "_".join(parts)
    while "__" in base_name: 
        base_name = base_name.replace("__", "_")
    
    if not base_name:
        base_name = "Render"

    return base_name

def setup_render_path(context):
    scene = context.scene
    props = scene.studio_tool_props
    
    filename = generate_render_filename(scene, props)
    
    mode = props.save_destination
    root_folder = ""

    if mode == 'RELATIVE':
        root_folder = "//Renders/"
    
    elif mode == 'CUSTOM':
        root_folder = props.root_path
        if not root_folder.endswith(os.sep) and not root_folder.endswith("/"):
            root_folder += os.sep

    elif mode == 'DESKTOP':
        root_folder = os.path.join(os.path.expanduser("~"), "Desktop") + os.sep
        
    final_path = f"{root_folder}{filename}/{filename}_"
    
    scene.render.filepath = final_path
    return final_path


# ==============================================================================
#   HELPER FUNCTIONS (GHOST COMPOSITOR)
# ==============================================================================

def update_compositor_setup(context, enable_ghost_mode, target_index):
    scene = context.scene
    selected_objects = context.selected_objects
    
    if enable_ghost_mode and not selected_objects: 
        return {"ERROR": "Please select an object first!"}

    if enable_ghost_mode:
        for obj in selected_objects: 
            obj.pass_index = target_index
    
    tree = None
    if hasattr(scene, "compositing_node_group"):
        if scene.compositing_node_group is None:
            new_tree = bpy.data.node_groups.new(name="Scene Compositor", type="CompositorNodeTree")
            scene.compositing_node_group = new_tree
        tree = scene.compositing_node_group
    elif hasattr(scene, "node_tree"):
        scene.use_nodes = True
        tree = scene.node_tree

    if tree is None: 
        return {"ERROR": "Could not access Compositor Node Tree."}

    try: context.view_layer.use_pass_object_index = True
    except: pass

    nodes = tree.nodes
    links = tree.links
    nodes.clear()

    def create_output_node(tree, nodes):
        try: return nodes.new(type="CompositorNodeComposite")
        except RuntimeError:
            comp = nodes.new(type="NodeGroupOutput")
            if hasattr(tree, "interface"):
                exists = any(item.name == "Image" and item.item_type == 'SOCKET' for item in tree.interface.items_tree)
                if not exists: tree.interface.new_socket(name="Image", socket_type="NodeSocketColor", in_out='OUTPUT')
            return comp
            
    def get_socket(node, possible_names, is_output=True):
        collection = node.outputs if is_output else node.inputs
        for n in possible_names:
            if n in collection: return collection[n]
        return collection[0] if len(collection) > 0 else None

    if enable_ghost_mode:
        rl_node = nodes.new(type="CompositorNodeRLayers")
        rl_node.location = (0, 0)

        id_mask = nodes.new(type="CompositorNodeIDMask")
        id_mask.location = (300, -200)
        
        idx_sock = id_mask.inputs.get("Index")
        if idx_sock: idx_sock.default_value = target_index
        elif len(id_mask.inputs) > 1: id_mask.inputs[1].default_value = target_index
        else:
            try: 
                id_mask.index = target_index
                id_mask.use_antialiasing = True
            except: pass

        invert = nodes.new(type="CompositorNodeInvert")
        invert.location = (500, -200)
        if "Fac" in invert.inputs: invert.inputs["Fac"].default_value = 1.0

        try:
            sep = nodes.new(type="CompositorNodeSeparateColor") 
            comb = nodes.new(type="CompositorNodeCombineColor")
        except:
            sep = nodes.new(type="CompositorNodeSepRGBA") 
            comb = nodes.new(type="CompositorNodeCombRGBA")
        
        sep.location = (500, 100)
        comb.location = (700, 0)
        comp = create_output_node(tree, nodes)
        comp.location = (950, 0)

        rl_idx = get_socket(rl_node, ["IndexOB", "IndexMA", "Index", "Object Index"])
        if rl_idx: links.new(rl_idx, id_mask.inputs[0])
        
        links.new(id_mask.outputs[0], invert.inputs[1])
        links.new(get_socket(rl_node, ["Image"]), get_socket(sep, ["Image"], False))
        
        for ch in ["Red", "Green", "Blue", "R", "G", "B"]:
            if sep.outputs.get(ch) and comb.inputs.get(ch): 
                links.new(sep.outputs[ch], comb.inputs[ch])
            
        links.new(invert.outputs[0], get_socket(comb, ["Alpha", "A"], False))
        links.new(comb.outputs[0], get_socket(comp, ["Image"], False))

        return {"INFO": f"Ghost Mode Active! (Index {target_index})"}
    
    else:
        rl = nodes.new(type="CompositorNodeRLayers")
        rl.location = (0, 0)
        comp = create_output_node(tree, nodes)
        comp.location = (400, 0)
        links.new(get_socket(rl, ["Image"]), get_socket(comp, ["Image"], False))
        return {"INFO": "Compositor reset to standard render."}


# ==============================================================================
#  LOGIC - STUDIO & CAMERA
# ==============================================================================

def mark_as_asset(obj):
    obj[TAG_KEY] = True

def check_studio_exists():
    return any(TAG_KEY in o.keys() for o in bpy.data.objects)

def delete_tagged_assets(exclude_obj=None):
    if bpy.context.mode != 'OBJECT':
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
        except:
            pass 
             
    candidates = [o for o in bpy.data.objects if TAG_KEY in o.keys()]
    if not candidates: return
    
    selected = bpy.context.selected_objects
    active = bpy.context.active_object
    
    bpy.ops.object.select_all(action='DESELECT')
    
    for obj in candidates:
        if obj == exclude_obj: continue 
        obj.select_set(True)
        
    bpy.ops.object.delete()
    
    for obj in selected:
        try:
            if obj.name in bpy.data.objects: 
                obj.select_set(True)
        except: pass
        
    if active: 
        try: 
            if active.name in bpy.data.objects:
                bpy.context.view_layer.objects.active = active
        except: pass

    for col in [bpy.data.meshes, bpy.data.lights, bpy.data.cameras]:
        for block in list(col):
            if block.users == 0: col.remove(block)

def get_ratio_float(ratio_enum):
    if ratio_enum == '16:9': return 1920/1080
    elif ratio_enum == '2.35:1': return 1920/817
    elif ratio_enum == '4:3': return 1920/1440
    elif ratio_enum == '3:2': return 1920/1280
    elif ratio_enum == '1:1': return 1.0
    elif ratio_enum == '2:3': return 1080/1620
    elif ratio_enum == '9:16': return 1080/1920
    return 1.777

def update_res_x(self, context):
    context.scene.render.resolution_x = self.res_x
    if self.lock_aspect_ratio:
        ratio = get_ratio_float(self.aspect_ratio)
        new_y = int(self.res_x / ratio)
        if self.res_y != new_y: 
            self.res_y = new_y 
            context.scene.render.resolution_y = new_y

def update_res_y(self, context):
    context.scene.render.resolution_y = self.res_y
    if self.lock_aspect_ratio:
        ratio = get_ratio_float(self.aspect_ratio)
        new_x = int(self.res_y * ratio)
        if self.res_x != new_x: 
            self.res_x = new_x
            context.scene.render.resolution_x = new_x

def apply_resolution(scene, ratio_enum):
    rx, ry = 1920, 1080
    if ratio_enum == '16:9': rx, ry = 1920, 1080
    elif ratio_enum == '2.35:1': rx, ry = 1920, 817
    elif ratio_enum == '4:3': rx, ry = 1920, 1440
    elif ratio_enum == '3:2': rx, ry = 1920, 1280
    elif ratio_enum == '1:1': rx, ry = 1080, 1080
    elif ratio_enum == '2:3': rx, ry = 1080, 1620
    elif ratio_enum == '9:16': rx, ry = 1080, 1920
    
    scene.render.resolution_x = rx
    scene.render.resolution_y = ry
    scene.render.resolution_percentage = 100
    
    if hasattr(scene, "studio_tool_props"):
        scene.studio_tool_props.res_x = rx
        scene.studio_tool_props.res_y = ry
        scene.studio_tool_props.quality_mode = 'HD'

def update_quality_mode(self, context):
    mode = self.quality_mode
    if mode == 'SD':
        context.scene.render.resolution_percentage = 50
    elif mode == 'HD':
        context.scene.render.resolution_percentage = 100
    elif mode == '4K':
        context.scene.render.resolution_percentage = 200
    elif mode == '8K':
        context.scene.render.resolution_percentage = 400
    elif mode == 'CUSTOM':
        context.scene.render.resolution_percentage = 100

def logic_create_studio_elements(context, target_obj=None, reuse_camera=None):
    scale_fac = get_object_scale_factor(target_obj)

    if reuse_camera:
        mark_as_asset(reuse_camera)
        context.scene.camera = reuse_camera
    else:
        if not context.scene.camera or TAG_KEY in context.scene.camera.keys():
            cam_data = bpy.data.cameras.new(name='Studio_Cam_Data')
            cam_obj = bpy.data.objects.new(name='Studio_Camera', object_data=cam_data)
            context.collection.objects.link(cam_obj)
            mark_as_asset(cam_obj)
            context.scene.camera = cam_obj

    if context.scene.camera:
        context.scene.camera.data.clip_end = 5000.0 * scale_fac
        
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        space.clip_end = 5000.0 * scale_fac


    bpy.ops.mesh.primitive_plane_add(size=1)
    backdrop = context.active_object
    backdrop.name = "Studio_Backdrop"
    mark_as_asset(backdrop)
    
    s = 10.0 * scale_fac
    
    mesh = backdrop.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()
    for v in bm.verts: bm.verts.remove(v)
    
    v1, v2 = bm.verts.new((-s, -s, 0)), bm.verts.new((s, -s, 0))
    v3, v4 = bm.verts.new((s, s, 0)), bm.verts.new((-s, s, 0))
    bm.faces.new((v1, v2, v3, v4))
    bm.edges.ensure_lookup_table()
    
    back_edge = None
    for e in bm.edges:
        if e.verts[0].co.y > 0 and e.verts[1].co.y > 0:
            back_edge = e; break
    if back_edge:
        res = bmesh.ops.extrude_edge_only(bm, edges=[back_edge])
        for v in [v for v in res['geom'] if isinstance(v, bmesh.types.BMVert)]:
            v.co.z += s 
    bm.to_mesh(mesh)
    bm.free()
    
    mod = backdrop.modifiers.new(name="Curve", type='BEVEL')
    mod.width = 4 * scale_fac 
    mod.segments = 20
    bpy.ops.object.shade_smooth()

    mat = bpy.data.materials.get("Studio_Dark_Grey")
    if not mat:
        mat = bpy.data.materials.new(name="Studio_Dark_Grey")
        mat.use_nodes = True
        mat.use_backface_culling = True

        tree = mat.node_tree
        nodes = tree.nodes
        links = tree.links

        nodes.clear()

        node_out   = nodes.new('ShaderNodeOutputMaterial')
        node_mix   = nodes.new('ShaderNodeMixShader')
        node_geo   = nodes.new('ShaderNodeNewGeometry')
        node_trans = nodes.new('ShaderNodeBsdfTransparent')
        node_bsdf  = nodes.new('ShaderNodeBsdfPrincipled')
        
        node_out.location   = (300, 0)
        node_mix.location   = (100, 0)
        node_bsdf.location  = (-200, 0)
        node_trans.location = (-200, -200)
        node_geo.location   = (-200, 200)

        node_bsdf.inputs['Base Color'].default_value = (0.02, 0.02, 0.02, 1.0)
        node_bsdf.inputs['Roughness'].default_value = 1.0
        
        if 'Specular IOR Level' in node_bsdf.inputs:
            node_bsdf.inputs['Specular IOR Level'].default_value = 0.2
        elif 'Specular' in node_bsdf.inputs:
            node_bsdf.inputs['Specular'].default_value = 0.2

        links.new(node_geo.outputs['Backfacing'], node_mix.inputs['Fac'])
        links.new(node_bsdf.outputs['BSDF'], node_mix.inputs[1])   
        links.new(node_trans.outputs['BSDF'], node_mix.inputs[2])  
        links.new(node_mix.outputs['Shader'], node_out.inputs['Surface'])
            
    if backdrop.data.materials: backdrop.data.materials[0] = mat
    else: backdrop.data.materials.append(mat)

    def make_light(name, loc, rot, energy):
        light_data = bpy.data.lights.new(name=f"{name}_Data", type='AREA')
        light_data.energy = energy * (scale_fac**2) 
        light_data.size = 5 * scale_fac
        light_obj = bpy.data.objects.new(name=name, object_data=light_data)
        context.collection.objects.link(light_obj)
        mark_as_asset(light_obj)
        new_loc = (loc[0]*scale_fac, loc[1]*scale_fac, loc[2]*scale_fac)
        light_obj.location = new_loc
        light_obj.rotation_euler = rot

    make_light("Key_Light", (-5, -5, 5), (math.radians(45), 0, math.radians(-45)), 500)
    make_light("Fill_Light", (5, -3, 3), (math.radians(45), 0, math.radians(45)), 300)
    make_light("Rim_Light", (0, 5, 5), (math.radians(-45), 0, 0), 400)
    
    context.scene.render.engine = 'CYCLES'
    context.scene.cycles.preview_samples = 128
    context.scene.cycles.samples = 128
    context.scene.cycles.use_preview_denoising = True

    try: context.scene.cycles.device = 'GPU'
    except: pass
    try: context.scene.view_settings.view_transform = 'AgX'
    except: context.scene.view_settings.view_transform = 'Filmic'
    world = bpy.data.worlds["World"]
    world.use_nodes = True
    world.node_tree.nodes["Background"].inputs[0].default_value = (0, 0, 0, 1)


def get_screen_bounds(scene, camera, obj):
    min_x, max_x = 100.0, -100.0
    min_y, max_y = 100.0, -100.0
    mw = obj.matrix_world
    for corner in obj.bound_box:
        world_pos = mw @ Vector(corner)
        co = world_to_camera_view(scene, camera, world_pos)
        if co.x < min_x: min_x = co.x
        if co.x > max_x: max_x = co.x
        if co.y < min_y: min_y = co.y
        if co.y > max_y: max_y = co.y
    return min_x, max_x, min_y, max_y

def snap_object_to_ground(obj, camera_obj=None):
    mw = obj.matrix_world
    corners = [mw @ Vector(corner) for corner in obj.bound_box]
    lowest_z = min(c.z for c in corners)
    offset_z = 0.0 - lowest_z
    obj.location.z += offset_z
    if camera_obj:
        camera_obj.location.z += offset_z

def fit_camera_to_object(context, cam, obj, fill_percent, lens_mm, angle_deg):
    if not cam: return
    cam.data.lens = lens_mm
    rad = radians(angle_deg)
    y_val = -cos(rad)
    z_val = sin(rad)
    offset_vector = Vector((0, y_val, z_val)) * 5.0
    mw = obj.matrix_world
    center = sum((mw @ Vector(c) for c in obj.bound_box), Vector()) / 8
    cam.location = center + offset_vector
    direction = center - cam.location
    rot_quat = direction.to_track_quat('-Z', 'Y')
    cam.rotation_euler = rot_quat.to_euler()
    context.view_layer.update()
    target_fill = fill_percent / 100.0
    for i in range(50):
        min_x, max_x, min_y, max_y = get_screen_bounds(context.scene, cam, obj)
        current_size = max(max_x - min_x, max_y - min_y)
        if current_size <= 0.0001: break
        ratio = target_fill / current_size
        if abs(1.0 - ratio) < 0.01: break
        direction_vec = center - cam.location
        move_fac = (1.0 - (1.0/ratio)) * 0.5 
        cam.location += direction_vec * move_fac
        context.view_layer.update()
    direction = center - cam.location
    rot_quat = direction.to_track_quat('-Z', 'Y')
    cam.rotation_euler = rot_quat.to_euler()

# ==============================================================================
#  LOGIC - WIREFRAME
# ==============================================================================

def update_wireframe_visuals(self, context):
    """Updates nodes on the Active Overlay Mat OR the Global Mats"""
    props = context.scene.studio_tool_props
    
    def apply_to_tree(tree):
        if not tree: return
        nodes = tree.nodes
        
        bsdf = nodes.get("Studio_Base_Node")
        if bsdf:
            c = props.wire_base_col
            bsdf.inputs['Base Color'].default_value = (c[0], c[1], c[2], 1.0)

        emit = nodes.get("Studio_Wire_Node")
        if emit:
            c = props.wire_line_col
            emit.inputs['Color'].default_value = (c[0], c[1], c[2], 1.0)

        math_node = nodes.get("Studio_Thick_Node")
        if math_node:
            new_threshold = 0.5 - props.wire_thick
            if new_threshold < 0: new_threshold = 0
            math_node.inputs[1].default_value = new_threshold

    obj = context.active_object
    active_mat = None
    if obj and obj.type == 'MESH' and obj.material_slots:
        if obj.material_slots[0].link == 'OBJECT':
            active_mat = obj.material_slots[0].material
            if active_mat and active_mat.use_nodes:
                apply_to_tree(active_mat.node_tree)

    for name in ["Studio_Wireframe_Dark", "Studio_Wireframe_Light", "Studio_Wireframe_Custom"]:
        mat = bpy.data.materials.get(name)
        if mat and mat != active_mat:
            apply_to_tree(mat.node_tree)

def apply_procedural_wireframe(context, style='DARK', target_mat=None):
    if bpy.context.mode != 'OBJECT':       
        try: bpy.ops.object.mode_set(mode='OBJECT')
        except: pass 
    
    selected_meshes = [o for o in context.selected_objects if o.type == 'MESH']
    if not selected_meshes: return False, "No meshes selected"

    props = context.scene.studio_tool_props
    WIRE_UV_NAME = "Studio_Wire_UV"

   
    if style == 'DARK':
        mat_name = "Studio_Wireframe_Dark"
        emission_str = 2.0
        props.wire_base_col = (0.05, 0.05, 0.05)
        props.wire_line_col = (0.0, 0.8, 1.0)
        props.wire_thick = 0.02
        
    elif style == 'LIGHT':
        mat_name = "Studio_Wireframe_Light"
        emission_str = 1.0
        props.wire_base_col = (1.0, 1.0, 1.0)
        props.wire_line_col = (0.0, 0.0, 0.0)
        props.wire_thick = 0.02
        
    elif style == 'CUSTOM':
        mat_name = "Studio_Wireframe_Custom"
        emission_str = 1.0

    bc = props.wire_base_col
    wc = props.wire_line_col
    base_color = (bc[0], bc[1], bc[2], 1.0)
    wire_color = (wc[0], wc[1], wc[2], 1.0)
    thick_val = props.wire_thick

    mat = bpy.data.materials.get(mat_name)
    if not mat: mat = bpy.data.materials.new(name=mat_name)
    
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    
    node_out = nodes.new('ShaderNodeOutputMaterial')
    node_out.location = (400, 0)
    
    node_bsdf = nodes.new('ShaderNodeBsdfPrincipled')
    node_bsdf.name = "Studio_Base_Node"
    node_bsdf.inputs['Base Color'].default_value = base_color
    node_bsdf.inputs['Roughness'].default_value = 0.8
    node_bsdf.location = (100, 0)

    node_emit = nodes.new('ShaderNodeEmission')
    node_emit.name = "Studio_Wire_Node"
    node_emit.inputs['Color'].default_value = wire_color
    node_emit.inputs['Strength'].default_value = emission_str
    node_emit.location = (100, -200)

    node_mix = nodes.new('ShaderNodeMixShader')
    node_mix.location = (250, 0)

    uv_map = nodes.new('ShaderNodeUVMap')
    uv_map.uv_map = WIRE_UV_NAME
    uv_map.location = (-800, 300)
    
    sep = nodes.new('ShaderNodeSeparateXYZ')
    sep.location = (-600, 300)
    
    math_u = nodes.new('ShaderNodeMath')
    math_u.operation, math_u.inputs[1].default_value = 'SUBTRACT', 0.5
    math_u.location = (-400, 300)
    abs_u = nodes.new('ShaderNodeMath')
    abs_u.operation = 'ABSOLUTE'
    abs_u.location = (-200, 300)
    
    math_v = nodes.new('ShaderNodeMath')
    math_v.operation, math_v.inputs[1].default_value = 'SUBTRACT', 0.5
    math_v.location = (-400, 100)
    abs_v = nodes.new('ShaderNodeMath')
    abs_v.operation = 'ABSOLUTE'
    abs_v.location = (-200, 100)
    
    n_max = nodes.new('ShaderNodeMath')
    n_max.operation = 'MAXIMUM'
    n_max.location = (0, 200)
    
    threshold = 0.5 - thick_val
    
    comp = nodes.new('ShaderNodeMath')
    comp.name = "Studio_Thick_Node"
    comp.operation = 'GREATER_THAN'
    comp.inputs[1].default_value = threshold
    comp.location = (0, -100)

    links.new(uv_map.outputs[0], sep.inputs[0])
    links.new(sep.outputs['X'], math_u.inputs[0])
    links.new(math_u.outputs[0], abs_u.inputs[0])
    links.new(sep.outputs['Y'], math_v.inputs[0])
    links.new(math_v.outputs[0], abs_v.inputs[0])
    links.new(abs_u.outputs[0], n_max.inputs[0])
    links.new(abs_v.outputs[0], n_max.inputs[1])
    links.new(n_max.outputs[0], comp.inputs[0])
    links.new(comp.outputs[0], node_mix.inputs[0])
    links.new(node_bsdf.outputs[0], node_mix.inputs[1])
    links.new(node_emit.outputs[0], node_mix.inputs[2])
    links.new(node_mix.outputs[0], node_out.inputs[0])

    for obj in selected_meshes:
        mesh = obj.data
        if WIRE_UV_NAME not in mesh.uv_layers:
            active_original = context.view_layer.objects.active
            context.view_layer.objects.active = obj
            
            new_uv = mesh.uv_layers.new(name=WIRE_UV_NAME)
            if new_uv:
                mesh.uv_layers.active = new_uv
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.uv.reset()
                bpy.ops.object.mode_set(mode='OBJECT')
                
                if len(mesh.uv_layers) > 1:
                    mesh.uv_layers.active = mesh.uv_layers[0]

            context.view_layer.objects.active = active_original

        if len(obj.material_slots) == 0:
            obj.data.materials.append(None)
        
        for slot in obj.material_slots:
            slot.link = 'OBJECT'
            slot.material = mat
            
    return True, f"Applied {style} Wireframe Overlay"


class TOOLS_OT_ApplyWireframeSmart(bpy.types.Operator):
    """Applies Wireframe Overlay (Auto-Generates UVs if needed)"""
    bl_idname = "tools.apply_wireframe_smart"
    bl_label = "Apply Wireframe"
    bl_options = {'REGISTER', 'UNDO'}
    
    style: bpy.props.EnumProperty(
        items=[('DARK', "Dark", ""), ('LIGHT', "Light", ""), ('CUSTOM', "Custom", "")],
        default='DARK'
    )

    def invoke(self, context, event):
        total_polys = 0
        needs_uv = False
        
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                if "Studio_Wire_UV" not in obj.data.uv_layers:
                    needs_uv = True
                    total_polys += len(obj.data.polygons)
        
        if needs_uv and total_polys > 100000:
            return context.window_manager.invoke_confirm(self, event, message=f"High Poly Count ({total_polys}). Generate UVs? This may freeze Blender briefly.")
            
        return self.execute(context)

    def execute(self, context):
        success, msg = apply_procedural_wireframe(context, style=self.style)
        if success: self.report({'INFO'}, msg)
        else: self.report({'WARNING'}, msg)
        return {'FINISHED'}

class TOOLS_OT_RestoreWireframe(bpy.types.Operator):
    """Removes Wireframe Overlay"""
    bl_idname = "tools.restore_wireframe"
    bl_label = "Restore Original"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                for slot in obj.material_slots:
                    if slot.link == 'OBJECT':
                        slot.material = None
                        slot.link = 'DATA'
        self.report({'INFO'}, "Restored Original Materials")
        return {'FINISHED'}

class TOOLS_OT_MakeWireUnique(bpy.types.Operator):
    """Detaches wireframe settings for this object"""
    bl_idname = "tools.make_wire_unique"
    bl_label = "Make Unique"
    
    def execute(self, context):
        obj = context.active_object
        if obj and obj.material_slots:
            slot = obj.material_slots[0]
            if slot.link == 'OBJECT' and slot.material:
                new_mat = slot.material.copy()
                new_mat.name = "Studio_Wireframe_Unique"
                slot.material = new_mat
                self.report({'INFO'}, "Created Unique Wireframe")
        return {'FINISHED'}

class TOOLS_OT_LinkWireGlobal(bpy.types.Operator):
    """Reverts to Global Custom Wireframe"""
    bl_idname = "tools.link_wire_global"
    bl_label = "Link Global"
    
    def execute(self, context):
        obj = context.active_object
        mat = bpy.data.materials.get("Studio_Wireframe_Custom") 
        if not mat: 
             bpy.ops.tools.apply_wireframe_smart(style='CUSTOM')
             mat = bpy.data.materials.get("Studio_Wireframe_Custom")
             
        if obj and obj.type == 'MESH' and obj.material_slots:
            obj.material_slots[0].link = 'OBJECT'
            obj.material_slots[0].material = mat
        return {'FINISHED'}



    
# ==============================================================================
#   DATA PROPERTIES
# ==============================================================================

class StudioMasterProps(bpy.types.PropertyGroup):
    target_object: bpy.props.PointerProperty(name="Model", type=bpy.types.Object)
    lock_composition: bpy.props.BoolProperty(name="Lock Composition", default=False)
    fit_slider: bpy.props.FloatProperty(name="Fit Frame %", default=90.0, min=10.0, max=100.0, subtype='PERCENTAGE')
    lens_focal: bpy.props.FloatProperty(name="Focal Length", default=85.0, min=10.0, max=300.0)
    cam_angle: bpy.props.FloatProperty(name="Camera Angle", default=0.0, min=-45.0, max=89.9)
    aspect_ratio: bpy.props.EnumProperty(
        name="Aspect Ratio",
        items=[
            ('16:9', "16:9 (TV)", "1920x1080"),
            ('2.35:1', "2.35:1 (Cinema)", "1920x817"),
            ('4:3', "4:3 (Classic)", "1920x1440"),
            ('3:2', "3:2 (Photo)", "1920x1280"),
            ('1:1', "1:1 (Square)", "1080x1080"),
            ('2:3', "2:3 (Portrait)", "1080x1620"),
            ('9:16', "9:16 (Story)", "1080x1920"),
        ],
        default='16:9'
    )
    
    lock_aspect_ratio: bpy.props.BoolProperty(name="Lock Ratio", default=True, description="Keep X and Y synchronized")
    
    quality_mode: bpy.props.EnumProperty(
        name="Quality",
        items=[
            ('SD', "SD", "Draft (50%)"),
            ('HD', "HD", "Standard (100%)"),
            ('4K', "4K", "Ultra (200%)"),
            ('8K', "8K", "Print (400%)"),
            ('CUSTOM', "Custom", "Manual X/Y"),
        ],
        default='HD',
        update=update_quality_mode
    )

    res_x: bpy.props.IntProperty(name="Resolution X", default=1920, min=4, update=update_res_x)
    res_y: bpy.props.IntProperty(name="Resolution Y", default=1080, min=4, update=update_res_y)
    
    turntable_axis: bpy.props.EnumProperty(
        name="Axis", items=[('0', "X Axis", ""), ('1', "Y Axis", ""), ('2', "Z Axis (Up)", "")], default='2'
    )
    
    wire_base_col: bpy.props.FloatVectorProperty(
        name="Base Color", subtype='COLOR', default=(0.0, 0.0, 0.0), min=0.0, max=1.0, size=3, update=update_wireframe_visuals
    )
    wire_line_col: bpy.props.FloatVectorProperty(
        name="Wire Color", subtype='COLOR', default=(0.0, 1.0, 0.0), min=0.0, max=1.0, size=3, update=update_wireframe_visuals
    )
    wire_thick: bpy.props.FloatProperty(
        name="Thickness", default=0.02, min=0.001, max=0.49, step=0.005, update=update_wireframe_visuals
    )

    save_destination: bpy.props.EnumProperty(
        name="Destination",
        items=[
            ('RELATIVE', "Project Folder", "Save next to blend file (//Renders/)"),
            ('CUSTOM', "Custom Folder", "Use a specific fixed folder"),
            ('DESKTOP', "Desktop", "Save to a folder on the Desktop"),
        ],
        default='RELATIVE'
    )

    root_path: bpy.props.StringProperty(
        name="Path",
        default="C:/Renders/",
        description="Only used when Custom Folder is selected",
        subtype='DIR_PATH' 
    )

    use_date: bpy.props.BoolProperty(name="Date (Today)", default=False)
    use_filename: bpy.props.BoolProperty(name="File Name", default=True)
    use_scene: bpy.props.BoolProperty(name="Scene Name", default=False) 
    use_camera: bpy.props.BoolProperty(name="Active Camera", default=False)
    use_custom: bpy.props.BoolProperty(name="Add Tag", default=False)
    custom_text: bpy.props.StringProperty(name="Tag Text", default="Draft")
    
    file_format: bpy.props.EnumProperty(
        name="Format",
        items=[
            ('PNG', "PNG", ""),
            ('JPEG', "JPEG", ""),
            ('OPEN_EXR', "OpenEXR", ""),
        ],
        default='PNG'
    )

    ghost_index: bpy.props.IntProperty(
        name="Object ID",
        description="The Pass Index assigned to the object",
        default=99, min=1, max=1000
    )


class AO_Properties(bpy.types.PropertyGroup):
    ao_distance: bpy.props.FloatProperty(
        name="Distance", default=0.5, min=0.0, update=update_ao_shader
    )
    ao_contrast: bpy.props.FloatProperty(
        name="Contrast", default=1.5, min=0.1, soft_max=5.0, update=update_ao_shader
    )
    roughness: bpy.props.FloatProperty(
        name="Roughness", default=0.6, min=0.0, max=1.0, update=update_ao_shader
    )
    color_crevice: bpy.props.FloatVectorProperty(
        name="Crevice Color", subtype='COLOR', default=(0.0, 0.0, 0.0, 1.0),
        size=4, min=0.0, max=1.0, update=update_ao_shader
    )
    color_surface: bpy.props.FloatVectorProperty(
        name="Surface Color", subtype='COLOR', default=(0.8, 0.8, 0.8, 1.0),
        size=4, min=0.0, max=1.0, update=update_ao_shader
    )
    ao_inside: bpy.props.BoolProperty(
        name="Inside", default=False, update=update_ao_shader
    )

class SSS_Properties(bpy.types.PropertyGroup):
    sss_radius_color: bpy.props.FloatVectorProperty(
        name="Radius Color", subtype='COLOR', default=(1.0, 0.2, 0.1), 
        size=3, min=0.0, max=1.0, update=update_sss,
        description="The scatter color (Red for skin/blood)"
    )
    sss_scale: bpy.props.FloatProperty(
        name="Scale", default=0.05, min=0.0, step=0.01, precision=3, update=update_sss,
        description="How deep the light penetrates (in meters)"
    )


class Weathering_Properties(bpy.types.PropertyGroup):
    w_dirt_color: bpy.props.FloatVectorProperty(name="Dirt Color", subtype='COLOR', size=4, default=(0.1, 0.08, 0.05, 1.0), min=0.0, max=1.0, update=update_weathering_values)
    w_dirt_amount: bpy.props.FloatProperty(name="Amount", default=0.8, min=0.0, max=1.0, update=update_weathering_values)
    w_dirt_spread: bpy.props.FloatProperty(name="Spread", default=0.5, min=0.01, max=1.0, update=update_weathering_values)
    w_dirt_texture: bpy.props.FloatProperty(name="Texture", default=0.5, min=0.0, max=1.0, update=update_weathering_values)
    w_global_scale: bpy.props.FloatProperty(name="Scale", default=0.2, min=0.01, max=10.0, update=update_weathering_values)

    w_breakup_cov: bpy.props.FloatProperty(name="Clean Patches", description="How much of the model is Clean vs Dirty", default=0.0, min=0.0, max=1.0, update=update_weathering_values)
    w_breakup_scale: bpy.props.FloatProperty(name="Pattern Size", default=1.0, min=0.1, max=10.0, update=update_weathering_values)
    w_breakup_cont: bpy.props.FloatProperty(name="Sharpness", description="Sharpness of patches", default=0.5, min=0.0, max=1.0, update=update_weathering_values)

    w_edge_amount: bpy.props.FloatProperty(name="Amount", default=0.8, min=0.0, max=1.0, update=update_weathering_values)
    w_edge_sense: bpy.props.FloatProperty(name="Sensitivity", default=0.5, min=0.0, max=2.0, update=update_weathering_values)
    w_bump_val: bpy.props.FloatProperty(name="Bump", default=0.2, min=0.0, max=1.0, update=update_weathering_values)


# ==============================================================================
#   OPERATORS (STUDIO)
# ==============================================================================

class STUDIO_OT_RunSetup(bpy.types.Operator):
    bl_idname = "studio.run_setup"
    bl_label = "Studio Manager"
    mode: bpy.props.EnumProperty(items=[('REBUILD', "Rebuild", ""), ('CAMERA', "Cam Only", "")], default='REBUILD')

    @classmethod
    def poll(cls, context): return True

    def invoke(self, context, event):
        props = context.scene.studio_tool_props
        target_obj = props.target_object

        if not target_obj:
            if context.active_object and context.active_object.type == 'MESH':
                target_obj = context.active_object
                props.target_object = target_obj 
            else:
                self.report({'ERROR'}, "Please select a Mesh object first.")
                return {'CANCELLED'}

        if check_studio_exists():
            return context.window_manager.invoke_props_dialog(self, width=300)
        self.mode = 'REBUILD'
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Studio assets detected!", icon='INFO')
        layout.separator()
        layout.prop(self, "mode", expand=True)

    def execute(self, context):
        props = context.scene.studio_tool_props
        target_obj = props.target_object            

        if not target_obj:
            self.report({'ERROR'}, "No Target Object found.")
            return {'CANCELLED'}

        preserve_cam = None
        if props.lock_composition:
            preserve_cam = context.scene.camera
            if not preserve_cam:
                self.report({'WARNING'}, "Lock Composition ON but no camera active.")

        if self.mode == 'REBUILD':
            delete_tagged_assets(exclude_obj=preserve_cam)
            logic_create_studio_elements(context, target_obj=target_obj, reuse_camera=preserve_cam)
        
        apply_resolution(context.scene, props.aspect_ratio)
        cam = context.scene.camera
        
        if props.lock_composition and cam:
            snap_object_to_ground(target_obj, camera_obj=cam)
            self.report({'INFO'}, "Composition Locked: Adjusted Height.")
        else:
            snap_object_to_ground(target_obj, camera_obj=None)
            bpy.ops.object.select_all(action='DESELECT')
            target_obj.select_set(True)
            context.view_layer.objects.active = target_obj
            
            if cam:
                fit_camera_to_object(context, cam, target_obj, props.fit_slider, props.lens_focal, props.cam_angle)

        bpy.ops.object.select_all(action='DESELECT')
        
        if target_obj:
            target_obj.select_set(True)
            context.view_layer.objects.active = target_obj

        if cam:
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.spaces[0].region_3d.view_perspective = 'CAMERA'

        return {'FINISHED'}
        
# ==============================================================================
#   OPERATORS (TURNTABLE)
# ==============================================================================

class OBJECT_OT_ReverseTurntableDirection(bpy.types.Operator):
    bl_idname = "object.reverse_turntable_direction"
    bl_label = "Reverse Spin"
    def execute(self, context):
        obj = context.active_object
        if obj:
            current_dir = obj.get("tt_direction", 1)
            obj["tt_direction"] = current_dir * -1
            obj.update_tag()
            context.view_layer.update()
        return {'FINISHED'}

class OBJECT_OT_RemoveTurntable(bpy.types.Operator):
    bl_idname = "object.remove_turntable"
    bl_label = "Remove Turntable"
    def execute(self, context):
        obj = context.active_object
        if not obj: return {'CANCELLED'}
        if obj.animation_data and obj.animation_data.drivers:
            drivers_to_remove = [d for d in obj.animation_data.drivers if d.data_path == "rotation_euler"]
            for d in drivers_to_remove: obj.animation_data.drivers.remove(d)
        for k in ["tt_is_active", "tt_seconds", "tt_frames", "tt_direction"]: 
            if k in obj: del obj[k]
        obj.rotation_euler = (0,0,0)
        self.report({'INFO'}, "Turntable Removed")
        return {'FINISHED'}

class OBJECT_OT_AddTurntableDriver(bpy.types.Operator):
    bl_idname = "object.add_turntable_driver"
    bl_label = "Add Turntable"
    axis: bpy.props.EnumProperty(items=[('0', "X", ""), ('1', "Y", ""), ('2', "Z", "")], default='2')
    
    def execute(self, context):
        obj = context.active_object
        if not obj:
            self.report({'ERROR'}, "Select an object first!")
            return {'CANCELLED'}
        
        obj["tt_is_active"] = True  
        obj["tt_seconds"] = 5.0 
        obj["tt_direction"] = 1      
        obj.rotation_mode = 'XYZ'
        
        driver = obj.driver_add("rotation_euler", int(self.axis)).driver
        driver.type = 'SCRIPTED'
        
        var_frame = driver.variables.new()
        var_frame.name = "frame"
        var_frame.type = 'SINGLE_PROP'
        var_frame.targets[0].id_type = 'SCENE'
        var_frame.targets[0].id = context.scene
        var_frame.targets[0].data_path = "frame_current"

        var_sec = driver.variables.new()
        var_sec.name = "seconds"
        var_sec.type = 'SINGLE_PROP'
        var_sec.targets[0].id_type = 'OBJECT'
        var_sec.targets[0].id = obj
        var_sec.targets[0].data_path = '["tt_seconds"]'
        
        var_fps = driver.variables.new()
        var_fps.name = "fps"
        var_fps.type = 'SINGLE_PROP'
        var_fps.targets[0].id_type = 'SCENE'
        var_fps.targets[0].id = context.scene
        var_fps.targets[0].data_path = "render.fps"

        var_dir = driver.variables.new()
        var_dir.name = "direction"
        var_dir.type = 'SINGLE_PROP'
        var_dir.targets[0].id_type = 'OBJECT'
        var_dir.targets[0].id = obj
        var_dir.targets[0].data_path = '["tt_direction"]'

        start = context.scene.frame_start
        driver.expression = f"(frame - {start}) / max(seconds * fps, 1) * 6.283185 * direction"
        return {'FINISHED'}

class OBJECT_OT_SyncTurntableRange(bpy.types.Operator):
    bl_idname = "object.sync_turntable_range"
    bl_label = "Sync Timeline"
    bl_description = "Calculates the end frame of your timeline for a perfect loop"

    def execute(self, context):
        obj = context.active_object
        if not obj or "tt_seconds" not in obj:
            return {'CANCELLED'}
        
        seconds = float(obj["tt_seconds"])
        fps = context.scene.render.fps
        total_frames = int(seconds * fps)
        
        context.scene.frame_start = 1
        context.scene.frame_end = total_frames
        
        self.report({'INFO'}, f"Timeline Fixed: {total_frames} frames ({seconds}s @ {fps}fps)")
        return {'FINISHED'}

class RENDER_OT_OpenOutputFolder(bpy.types.Operator):
    bl_idname = "render.open_output_folder"
    bl_label = "Open Folder"
    bl_description = "Opens the directory where renders are saved on your computer"

    def execute(self, context):
        filepath = context.scene.render.filepath
        if not filepath:
            self.report({'WARNING'}, "No output path set.")
            return {'CANCELLED'}
        
        abs_path = bpy.path.abspath(filepath)
        if not os.path.isdir(abs_path):
            abs_path = os.path.dirname(abs_path)
        
        if not os.path.exists(abs_path):
            self.report({'WARNING'}, f"Directory not found: {abs_path}")
            return {'CANCELLED'}
            
        bpy.ops.wm.path_open(filepath=abs_path)
        return {'FINISHED'}

# ==============================================================================
#   OPERATORS (AO)
# ==============================================================================

class AO_OT_ApplyShader(bpy.types.Operator):
    """Creates and applies the Original AO Shader Non-Destructively"""
    bl_idname = "ao.apply_shader"
    bl_label = "Apply AO Shader"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.ao_tools_props
        
        if context.scene.render.engine == 'BLENDER_EEVEE':
            try: context.scene.eevee.use_gtao = True
            except: pass 
        
        mat = bpy.data.materials.get(AO_MAT_NAME)
        if not mat: mat = bpy.data.materials.new(name=AO_MAT_NAME)
        
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        nodes.clear()

        node_out = nodes.new(type='ShaderNodeOutputMaterial')
        node_out.location = (400, 0)
        node_bsdf = nodes.new(type='ShaderNodeBsdfPrincipled')
        node_bsdf.name = "AO_Principled"
        node_bsdf.location = (100, 0)
        node_mix = nodes.new(type='ShaderNodeMix')
        node_mix.name = "AO_Color_Mix"
        node_mix.data_type = 'RGBA'
        node_mix.location = (-200, 0)
        node_gamma = nodes.new(type='ShaderNodeGamma')
        node_gamma.name = "AO_Gamma"
        node_gamma.location = (-400, 0)
        node_ao = nodes.new(type='ShaderNodeAmbientOcclusion')
        node_ao.name = "AO_Node"
        node_ao.location = (-600, 0)
        
        links.new(node_ao.outputs['Color'], node_gamma.inputs['Color'])
        links.new(node_gamma.outputs['Color'], node_mix.inputs['Factor'])
        links.new(node_mix.outputs['Result'], node_bsdf.inputs['Base Color'])
        links.new(node_bsdf.outputs['BSDF'], node_out.inputs['Surface'])

        update_ao_shader(props, context)

        selected_objects = context.selected_objects
        if not selected_objects:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}

        for obj in selected_objects:
            if obj.type == 'MESH':
                if len(obj.material_slots) == 0:
                    obj.data.materials.append(None)
                
                for slot in obj.material_slots:
                    slot.link = 'OBJECT'
                    slot.material = mat

        return {'FINISHED'}

class AO_OT_RestoreOriginal(bpy.types.Operator):
    """Removes the Clay Overlay and reveals original materials"""
    bl_idname = "ao.restore_original"
    bl_label = "Restore Original"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                for slot in obj.material_slots:
                    slot.link = 'DATA'
        
        self.report({'INFO'}, "Original Materials Restored")
        return {'FINISHED'}

class AO_OT_MakeUnique(bpy.types.Operator):
    """Duplicates the material so it is no longer affected by Global Presets"""
    bl_idname = "ao.make_unique"
    bl_label = "Make Unique"
    bl_description = "Detaches active object from global AO controls"
    
    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.material_slots:
            return {'CANCELLED'}
        
        slot = obj.material_slots[0]
        
        if slot.link == 'OBJECT' and slot.material:
            new_mat = slot.material.copy()
            new_mat.name = "AO_Unique_Mat"
            slot.material = new_mat
            self.report({'INFO'}, "Created Unique Material")
        
        return {'FINISHED'}

class AO_OT_RelinkGlobal(bpy.types.Operator):
    """Re-assigns the global AO material to this object"""
    bl_idname = "ao.relink_global"
    bl_label = "Revert to Global"
    bl_description = "Connects this object back to the main Global AO material"
    
    def execute(self, context):
        obj = context.active_object
        mat = bpy.data.materials.get(AO_MAT_NAME)
        
        if not mat:
            self.report({'ERROR'}, "Global material not found. Apply it first.")
            return {'CANCELLED'}
            
        if obj and obj.type == 'MESH' and obj.material_slots:
            obj.material_slots[0].link = 'OBJECT'
            obj.material_slots[0].material = mat
            
        self.report({'INFO'}, "Re-linked to Global AO")
        return {'FINISHED'}

class AO_OT_ResetGrey(bpy.types.Operator):
    """Default Grey Clay"""
    bl_idname = "ao.reset_grey"
    bl_label = "Grey Clay"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.ao_tools_props
        props.ao_distance = 1.0
        props.ao_contrast = 1.0
        props.roughness = 1.0
        props.color_crevice = (0.0, 0.0, 0.0, 1.0)
        props.color_surface = (0.8, 0.8, 0.8, 1.0)
        props.ao_inside = False
        
        if context.selected_objects: 
            bpy.ops.ao.apply_shader()
            
        return {'FINISHED'}

class AO_OT_RedWax(bpy.types.Operator):
    """ZBrush Red Wax Look"""
    bl_idname = "ao.preset_redwax"
    bl_label = "Red Wax (ZBrush)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.ao_tools_props
        props.color_surface = (0.35, 0.12, 0.09, 1.0) 
        props.color_crevice = (0.03, 0.01, 0.005, 1.0)
        props.roughness = 0.45 
        props.ao_distance = 0.4
        props.ao_contrast = 1.6
        if context.selected_objects: bpy.ops.ao.apply_shader()
        return {'FINISHED'}

class AO_OT_BeigeSculpey(bpy.types.Operator):
    """Real Super Sculpey (Beige)"""
    bl_idname = "ao.preset_beige"
    bl_label = "Beige Sculpey"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.ao_tools_props
        props.color_surface = (0.8, 0.55, 0.48, 1.0) 
        props.color_crevice = (0.2, 0.1, 0.05, 1.0)
        props.roughness = 0.6 
        props.ao_distance = 0.5
        props.ao_contrast = 1.2
        if context.selected_objects: bpy.ops.ao.apply_shader()
        return {'FINISHED'}

# ==============================================================================
#   OPERATORS (TOOLBOX)
# ==============================================================================

class TOOLS_OT_MakeInvisible(bpy.types.Operator):
    bl_idname = "tools.make_invisible"
    bl_label = "Disable Primary Visibility"
    bl_description = "Disables Primary Visibility on selected objects (Visible in Reflections/Shadows)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected = context.selected_objects
        if not selected:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}

        count = 0
        for obj in selected:
            obj.visible_camera = False
            count += 1
        
        self.report({'INFO'}, f"Hidden {count} objects from Camera (Phantom Mode)")
        return {'FINISHED'}


class TOOLS_OT_RestoreVisibility(bpy.types.Operator):
    bl_idname = "tools.restore_visibility"
    bl_label = "Enable Primary Visibility"
    bl_description = "Restores Primary Visibility"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected = context.selected_objects
        if not selected:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}

        count = 0
        for obj in selected:
            obj.visible_camera = True
            
            if hasattr(obj, "is_holdout"):
                obj.is_holdout = False
            
            count += 1
        
        self.report({'INFO'}, f"Restored visibility for {count} objects")
        return {'FINISHED'}


class TOOLS_OT_MakeShadowCatcher(bpy.types.Operator):
    bl_idname = "tools.make_shadow_catcher"
    bl_label = "Turn On Shadow Catcher"
    bl_description = "Object becomes invisible but catches shadows. Renders BG if Film Transparent is OFF."
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected = context.selected_objects
        if not selected:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}
        
        if context.scene.render.engine != 'CYCLES':
            self.report({'INFO'}, "Note: Shadow Catcher works best in Cycles")

        count = 0
        for obj in selected:
            obj.is_shadow_catcher = True
            count += 1
            
        self.report({'INFO'}, f"Converted {count} objects to Shadow Catchers")
        return {'FINISHED'}


class TOOLS_OT_RestoreShadowCatcher(bpy.types.Operator):
    bl_idname = "tools.restore_shadow_catcher"
    bl_label = "Turn Off Shadow Catcher"
    bl_description = "Restores object to a solid mesh"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected = context.selected_objects
        if not selected:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}

        for obj in selected:
            obj.is_shadow_catcher = False
            
        self.report({'INFO'}, "Restored Solid Floors")
        return {'FINISHED'}

class TOOLS_OT_ExcludeGhost(bpy.types.Operator):
    bl_idname = "tools.exclude_ghost"
    bl_label = "Clear Object ID"
    bl_description = "Resets Object ID (Pass Index) to 0 for selected objects" 

    def execute(self, context):
        for obj in context.selected_objects:
            obj.pass_index = 0  
        self.report({'INFO'}, "Object removed from Ghost Group")
        return {'FINISHED'}

class TOOLS_OT_ApplyGhost(bpy.types.Operator):
    bl_idname = "tools.apply_ghost"
    bl_label = "Isolate via Object ID"
    bl_description = "Assigns Object ID to selected objects and generates AOV nodes" 

    def execute(self, context):
        props = context.scene.studio_tool_props
        res = update_compositor_setup(context, True, props.ghost_index)
        if "ERROR" in res:
            self.report({'ERROR'}, res["ERROR"])
            return {'CANCELLED'}
        self.report({'INFO'}, res["INFO"])
        return {'FINISHED'}

class TOOLS_OT_RemoveGhost(bpy.types.Operator):
    bl_idname = "tools.remove_ghost"
    bl_label = "Reset Nodetree"
    bl_description = "Clears generated nodes and resets to default"

    def execute(self, context):
        res = update_compositor_setup(context, False, 0)
        self.report({'INFO'}, res["INFO"])
        return {'FINISHED'}


class MATTOOLS_OT_MakeUnique(bpy.types.Operator):
    """Safely duplicates the material for tweaking"""
    bl_idname = "mattools.make_unique"
    bl_label = "Make Unique"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.material_slots: return {'CANCELLED'}
        
        slot = obj.material_slots[0]
        if slot.material:
            new_mat = slot.material.copy()
            new_mat.name = f"{slot.material.name}_Tweak"
            slot.link = 'OBJECT'
            slot.material = new_mat
            self.report({'INFO'}, "Material duplicated for safe tweaking")
            
        return {'FINISHED'}


# ==============================================================================
#   OPERATORS (MATERIAL TOOLS)
# ==============================================================================

class MATTOOLS_OT_RestoreOriginal(bpy.types.Operator):
    """Discards the unique tweak and restores original material"""
    bl_idname = "mattools.restore_original"
    bl_label = "Restore Original"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.material_slots: return {'CANCELLED'}
        obj.material_slots[0].link = 'DATA'
        self.report({'INFO'}, "Restored Original Material")
        return {'FINISHED'}

class MATTOOLS_OT_LinkEmission(bpy.types.Operator):
    bl_idname = "mattools.link_emission"
    bl_label = "Link Base to Emission"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        obj = context.active_object
        mat = ensure_unique_material(obj)
        if not mat: return {'CANCELLED'}
        
        bsdf = get_principled(mat)
        if not bsdf: return {'CANCELLED'}
        
        base, emit = bsdf.inputs.get('Base Color'), bsdf.inputs.get('Emission Color') or bsdf.inputs.get('Emission')
        if base and emit:
            if base.is_linked: mat.node_tree.links.new(base.links[0].from_socket, emit)
            else: emit.default_value = base.default_value
            if 'Emission Strength' in bsdf.inputs and bsdf.inputs['Emission Strength'].default_value == 0:
                bsdf.inputs['Emission Strength'].default_value = 1.0
        return {'FINISHED'}


class MATTOOLS_OT_AddControl(bpy.types.Operator):
    bl_idname = "mattools.add_control"
    bl_label = "Add Control"
    bl_options = {'REGISTER', 'UNDO'}
    input_target: bpy.props.StringProperty() 
    def execute(self, context):
        obj = context.active_object
        mat = ensure_unique_material(obj)
        if not mat: return {'CANCELLED'}

        bsdf = get_principled(mat)
        source_node, link = get_linked_node(bsdf, self.input_target)
        if not source_node: return {'CANCELLED'}
        
        out = get_output_node(mat)
        is_solo = False
        if out and out.inputs['Surface'].links:
            if out.inputs['Surface'].links[0].from_socket == link.from_socket:
                is_solo = True

        if is_data_input(self.input_target) and source_node.type == 'TEX_IMAGE':
            fix_texture_colorspace(source_node)
        
        nodes, links = mat.node_tree.nodes, mat.node_tree.links
        socket_type = bsdf.inputs[self.input_target].type 
        
        if socket_type == 'RGBA':
            control = nodes.new('ShaderNodeHueSaturation')
            control.inputs['Saturation'].default_value = 1.0
            control.inputs['Value'].default_value = 1.0
            in_sock, out_sock = 'Color', 'Color'
        else:
            control = nodes.new('ShaderNodeMapRange')
            in_sock, out_sock = 'Value', 'Result'

        control.location = (source_node.location.x + 50, source_node.location.y - 50)
        control.hide = True 
        
        links.new(link.from_socket, control.inputs[in_sock])
        links.new(control.outputs[out_sock], link.to_socket)
        
        if is_solo:
            links.new(control.outputs[out_sock], out.inputs['Surface'])
            
        return {'FINISHED'}

class MATTOOLS_OT_RemoveControl(bpy.types.Operator):
    bl_idname = "mattools.remove_control"
    bl_label = "Remove Control"
    bl_options = {'REGISTER', 'UNDO'}
    input_target: bpy.props.StringProperty() 
    def execute(self, context):
        obj = context.active_object
        mat = ensure_unique_material(obj) 
        if not mat: return {'CANCELLED'}

        bsdf = get_principled(mat)
        tweak_node, link = get_linked_node(bsdf, self.input_target)
        if not tweak_node: return {'CANCELLED'}
        
        out = get_output_node(mat)
        is_solo = False
        if out and out.inputs['Surface'].links:
            if out.inputs['Surface'].links[0].from_node == tweak_node:
                is_solo = True
        
        input_socket_name = 'Color' if tweak_node.type == 'HUE_SATURATION' else 'Value'
        original_link = None
        if input_socket_name in tweak_node.inputs and tweak_node.inputs[input_socket_name].links:
            original_link = tweak_node.inputs[input_socket_name].links[0]
            
        mat.node_tree.links.remove(link)
        
        if original_link:
            mat.node_tree.links.new(original_link.from_socket, bsdf.inputs[self.input_target])
            if is_solo:
                mat.node_tree.links.new(original_link.from_socket, out.inputs['Surface'])
        elif is_solo:
            mat.node_tree.links.new(bsdf.outputs[0], out.inputs['Surface'])

        mat.node_tree.nodes.remove(tweak_node)
        return {'FINISHED'}


class MATTOOLS_OT_ResetControl(bpy.types.Operator):
    bl_idname = "mattools.reset_control"
    bl_label = "Reset Settings"
    bl_options = {'REGISTER', 'UNDO'}
    input_target: bpy.props.StringProperty() 
    def execute(self, context):
        obj = context.active_object
        mat = ensure_unique_material(obj) 
        if not mat: return {'CANCELLED'}

        bsdf = get_principled(mat)
        node, link = get_linked_node(bsdf, self.input_target)
        if node:
            if node.bl_idname == 'ShaderNodeHueSaturation':
                for k, v in {'Hue':0.5, 'Saturation':1.0, 'Value':1.0, 'Fac':1.0}.items():
                    if k in node.inputs: node.inputs[k].default_value = v
            elif node.bl_idname == 'ShaderNodeMapRange':
                if 'To Min' in node.inputs: node.inputs['To Min'].default_value = 0.0
                if 'To Max' in node.inputs: node.inputs['To Max'].default_value = 1.0
        return {'FINISHED'}

class MATTOOLS_OT_FixColorSpaces(bpy.types.Operator):
    bl_idname = "mattools.fix_color_spaces"
    bl_label = "Fix Color Space"
    bl_options = {'REGISTER', 'UNDO'}
    target_input: bpy.props.StringProperty(default="")
    def execute(self, context):
        obj = context.active_object
        mat = ensure_unique_material(obj)
        if not mat: return {'CANCELLED'}

        bsdf = get_principled(mat)
        count = 0
        check_list = [self.target_input] if self.target_input else ['Roughness', 'Metallic', 'Specular', 'Normal']
        for name in check_list:
            node, link = get_linked_node(bsdf, name)
            if node and node.type == 'TEX_IMAGE' and fix_texture_colorspace(node): count += 1
            elif name == 'Normal' and node and node.type == 'NORMAL_MAP':
                 if node.inputs['Color'].links and fix_texture_colorspace(node.inputs['Color'].links[0].from_node): count += 1
        if count > 0: self.report({'INFO'}, f"Fixed {count} Color Spaces")
        return {'FINISHED'}

class MATTOOLS_OT_SoloInput(bpy.types.Operator):
    bl_idname = "mattools.solo_input"
    bl_label = "Solo Input"
    bl_options = {'REGISTER', 'UNDO'}
    input_target: bpy.props.StringProperty()
    def execute(self, context):
        obj = context.active_object
        mat = ensure_unique_material(obj) 
        if not mat: return {'CANCELLED'}

        bsdf = get_principled(mat)
        out = get_output_node(mat)
        source_node, link = get_linked_node(bsdf, self.input_target)
        
        if not source_node: return {'CANCELLED'}
        sock_to_solo = link.from_socket
        if self.input_target == 'Normal' and source_node.type == 'NORMAL_MAP' and source_node.inputs['Color'].links:
             sock_to_solo = source_node.inputs['Color'].links[0].from_socket

        is_solo = False
        if out.inputs['Surface'].links and out.inputs['Surface'].links[0].from_socket == sock_to_solo:
            is_solo = True
        
        if is_solo: mat.node_tree.links.new(bsdf.outputs[0], out.inputs['Surface'])
        else: mat.node_tree.links.new(sock_to_solo, out.inputs['Surface'])
        return {'FINISHED'}


class SSS_OT_Init(bpy.types.Operator):
    """Safely duplicates material to Object Slot for SSS tweaking"""
    bl_idname = "sss.init"
    bl_label = "Initialize SSS"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj: return {'CANCELLED'}
        
        mat = ensure_unique_material(obj) 
        if mat:
            self.report({'INFO'}, "Material duplicated for SSS")
            update_sss(context.scene.sss_props, context)
            
        return {'FINISHED'}

class SSS_OT_Restore(bpy.types.Operator):
    """Removes SSS Tweak and restores original Data material"""
    bl_idname = "sss.restore"
    bl_label = "Restore Original"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if obj and obj.material_slots:
            obj.material_slots[0].link = 'DATA'
            self.report({'INFO'}, "Original Material Restored")
        return {'FINISHED'}

class SSS_OT_Preset(bpy.types.Operator):
    bl_idname = "sss.set_preset"
    bl_label = "Set Preset"
    bl_options = {'REGISTER', 'UNDO'}
    mode: bpy.props.EnumProperty(items=[('HUMAN', "Human", ""), ('ALIEN', "Alien", ""), ('MARBLE', "Marble", ""), ('BLUE', "Avatar", "")])

    def execute(self, context):
        bpy.ops.sss.init()
        
        props = context.scene.sss_props
        if self.mode == 'HUMAN':
            props.sss_radius_color = (1.0, 0.2, 0.1)
            props.sss_scale = 0.05
        elif self.mode == 'ALIEN':
            props.sss_radius_color = (0.2, 1.0, 0.1)
            props.sss_scale = 0.1
        elif self.mode == 'MARBLE':
            props.sss_radius_color = (0.8, 0.8, 0.75)
            props.sss_scale = 0.15
        elif self.mode == 'BLUE':
            props.sss_radius_color = (0.1, 0.2, 1.0)
            props.sss_scale = 0.05
            
        update_sss(props, context)
        return {'FINISHED'}


# ==============================================================================
#   OPERATORS (WEATHERING)
# ==============================================================================

class WEATHER_OT_Apply(bpy.types.Operator):
    bl_idname = "weather.apply"
    bl_label = "Enable Weathering"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj: return {'CANCELLED'}
        
        mat = ensure_unique_material(obj)
        if not mat: 
            self.report({'ERROR'}, "Object has no material to weather.")
            return {'CANCELLED'}
            
        bsdf = get_principled(mat)
        if not bsdf:
            self.report({'ERROR'}, "No Principled BSDF found.")
            return {'CANCELLED'}
            
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        
        weather_tree = ensure_weathering_group()
        g_node = nodes.new(type='ShaderNodeGroup')
        g_node.node_tree = weather_tree
        g_node.name = "Weathering_Node"
        g_node.location = (bsdf.location.x - 300, bsdf.location.y)
        
        base_socket = bsdf.inputs['Base Color']
        
        if base_socket.is_linked:
            link = base_socket.links[0]
            links.new(link.from_socket, g_node.inputs['Base Color'])
        else:
            g_node.inputs['Base Color'].default_value = base_socket.default_value
            
        links.new(g_node.outputs['Result Color'], base_socket)
        
        links.new(g_node.outputs['Normal'], bsdf.inputs['Normal'])
        
        update_weathering_values(None, context)
        
        self.report({'INFO'}, "Weathering Applied")
        return {'FINISHED'}

class WEATHER_OT_Remove(bpy.types.Operator):
    bl_idname = "weather.remove"
    bl_label = "Disable Weathering"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.active_material: return {'CANCELLED'}
        mat = obj.active_material
        
        node = None
        for n in mat.node_tree.nodes:
            if n.type == 'GROUP' and n.node_tree and "Pro_Weathering_FX" in n.node_tree.name:
                node = n
                break
        
        if not node: return {'CANCELLED'}
        
        bsdf = get_principled(mat)
        if bsdf:
            if node.inputs['Base Color'].is_linked:
                original_link = node.inputs['Base Color'].links[0]
                mat.node_tree.links.new(original_link.from_socket, bsdf.inputs['Base Color'])
            else:
                saved_color = node.inputs['Base Color'].default_value
                bsdf.inputs['Base Color'].default_value = saved_color
        
        mat.node_tree.nodes.remove(node)
        self.report({'INFO'}, "Weathering Removed")
        return {'FINISHED'}
    


# ==============================================================================
#   OPERATORS (SMART RENDER EXECUTION)
# ==============================================================================

class STUDIO_OT_SmartStill(bpy.types.Operator):
    bl_idname = "studio.render_still"
    bl_label = "Render Image"
    
    def execute(self, context):
        props = context.scene.studio_tool_props
        
        force_disable_solo(context)

        if props.save_destination == 'RELATIVE' and not bpy.data.filepath:
            self.report({'ERROR'}, "Save file first to use Project Folder path!")
            return {'CANCELLED'}

        path = setup_render_path(context)
        context.scene.render.image_settings.file_format = props.file_format
        bpy.ops.render.render('INVOKE_DEFAULT', write_still=True)
        self.report({'INFO'}, f"Saved to: {path}")
        return {'FINISHED'}

class STUDIO_OT_SmartAnim(bpy.types.Operator):
    bl_idname = "studio.render_anim"
    bl_label = "Render Animation"
    
    def execute(self, context):
        props = context.scene.studio_tool_props

        force_disable_solo(context)

        if props.save_destination == 'RELATIVE' and not bpy.data.filepath:
            self.report({'ERROR'}, "Save file first to use Project Folder path!")
            return {'CANCELLED'}

        path = setup_render_path(context)
        context.scene.render.image_settings.file_format = props.file_format
        bpy.ops.render.render('INVOKE_DEFAULT', animation=True)
        self.report({'INFO'}, f"Rendering to: {path}")
        return {'FINISHED'}



# ==============================================================================
#   UI PANELS
# ==============================================================================

class STUDIO_PT_MainPanel(bpy.types.Panel):
    bl_label = "One Click Studio"
    bl_idname = "STUDIO_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Asset Stage"

    def draw(self, context):
        layout = self.layout
        props = context.scene.studio_tool_props
        row = layout.row(align=True)
        row.scale_y = 0.9  
        row.prop(props, "target_object", text="My Model", icon='SHADING_BBOX') 
        box = layout.box()
        col = box.column(align=True)
        row = col.row()
        row.prop(props, "lock_composition", icon='LOCKED' if props.lock_composition else 'UNLOCKED')
        col.separator()
        col.prop(props, "aspect_ratio", text="Ratio")
        
        if not props.lock_composition:
            col.separator()
            col.prop(props, "fit_slider", slider=True)
            col.prop(props, "lens_focal")
            col.prop(props, "cam_angle", slider=True)
        else:
            col.separator()
            col.label(text="Manual Framing Active", icon='CAMERA_DATA')
        
        col.separator()
        btn_text = "Update Studio" if check_studio_exists() else "Generate Studio"
        btn_icon = 'FILE_REFRESH' if check_studio_exists() else 'PLAY'
        sub = col.column()
        sub.scale_y = 2.5
        sub.operator("studio.run_setup", text=btn_text, icon=btn_icon)

class STUDIO_PT_TurntablePanel(bpy.types.Panel):
    bl_label = "Turntable"
    bl_idname = "STUDIO_PT_turntable"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Asset Stage"
    bl_options = {'DEFAULT_CLOSED'} 

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        props = context.scene.studio_tool_props

        if not obj:
            layout.label(text="Select an object", icon='INFO')
            return

        if "tt_is_active" in obj:
            box = layout.box()
            col = box.column(align=True)
            col.label(text="Speed Control:", icon='TIME')
            
            row = col.row()
            row.label(text="FPS:")
            row.prop(context.scene.render, "fps", text="")
            
            col.separator()
            
            if "tt_seconds" in obj:
                col.prop(obj, '["tt_seconds"]', text="Duration (Sec)")

                try:
                    sec = float(obj.get("tt_seconds", 0.0))
                    if sec > 0.01:
                        rpm = 60.0 / sec
                        col.label(text=f"Speed: {rpm:.1f} RPM", icon='DASHBOARD')
                except:
                    pass 
            else:
                col.label(text="Update Turntable!", icon='ERROR')
            
            col.separator()
            sub = col.row()
            sub.scale_y = 1.2
            sub.operator("object.sync_turntable_range", text="Fix Frame Range", icon='FILE_REFRESH')
            box_dir = layout.box()
            current_dir = obj.get("tt_direction", 1)
            row = box_dir.row()
            if current_dir == 1:
                row.label(text="Direction: CCW", icon='TRIA_LEFT')
            else:
                row.label(text="Direction: CW", icon='TRIA_RIGHT')
            box_dir.operator("object.reverse_turntable_direction", text="Reverse", icon='FILE_REFRESH')
            layout.separator()
            row = layout.row()
            row.alert = True
            row.operator("object.remove_turntable", text="Remove Turntable", icon='TRASH')
        else:
            col = layout.column(align=True)
            col.prop(props, "turntable_axis", text="Spin Axis")
            col.separator()
            op = col.operator("object.add_turntable_driver", text="Make 360° Animation", icon='PLAY')
            op.axis = props.turntable_axis

class STUDIO_PT_MaterialPanel(bpy.types.Panel):
    bl_label = "Material Tweaker"
    bl_idname = "STUDIO_PT_material"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Asset Stage"
    bl_options = {'DEFAULT_CLOSED'}

    def draw_socket_row(self, layout, bsdf, out_node, input_name, label_override=None):
        if input_name not in bsdf.inputs: return
        socket = bsdf.inputs[input_name]
        source_node, link = get_linked_node(bsdf, input_name)
        
        row = layout.row(align=True)
        if not source_node:
            row.label(text=label_override or input_name)
            row.prop(socket, "default_value", text="")
            return

        is_tweak_node = source_node.bl_idname in {'ShaderNodeHueSaturation', 'ShaderNodeMapRange'}
        
        real_image = source_node
        if is_tweak_node and source_node.inputs[0].links:
            real_image = source_node.inputs[0].links[0].from_node
        elif input_name == 'Normal' and source_node.type == 'NORMAL_MAP' and source_node.inputs['Color'].links:
             real_image = source_node.inputs['Color'].links[0].from_node
        
        sock_solo = link.from_socket 
        if input_name == 'Normal' and source_node.type == 'NORMAL_MAP' and source_node.inputs['Color'].links:
             sock_solo = source_node.inputs['Color'].links[0].from_socket

        is_active_solo = False
        if out_node and out_node.inputs['Surface'].links and out_node.inputs['Surface'].links[0].from_socket == sock_solo:
            is_active_solo = True

        row.label(text=label_override or input_name)
        img_name = get_image_name(real_image)
        if len(img_name) > 10: img_name = img_name[:8] + ".."
        col_n = row.column()
        col_n.enabled = False 
        col_n.alignment = 'RIGHT'
        col_n.label(text=img_name)

        if is_data_input(input_name) and real_image.type == 'TEX_IMAGE' and real_image.image and real_image.image.colorspace_settings.name != 'Non-Color':
            op = row.operator("mattools.fix_color_spaces", text="", icon='ERROR')
            op.target_input = input_name

        icon_type = 'HIDE_ON' if is_active_solo else 'HIDE_OFF'
        row.alert = is_active_solo
        row.operator("mattools.solo_input", text="", icon=icon_type, emboss=is_active_solo).input_target = input_name

        if not is_tweak_node:
            op = row.operator("mattools.add_control", text="", icon='PREFERENCES', emboss=False)
            op.input_target = input_name

        if is_tweak_node:
            box = layout.box()
            r_head = box.row()
            r_head.label(text="Settings", icon='MODIFIER')
            r_head.operator("mattools.reset_control", text="", icon='LOOP_BACK').input_target = input_name
            r_head.operator("mattools.remove_control", text="", icon='TRASH').input_target = input_name

            col = box.column(align=True)
            if source_node.bl_idname == 'ShaderNodeHueSaturation':
                for k in ['Hue', 'Saturation', 'Value']: 
                    if k in source_node.inputs: col.prop(source_node.inputs[k], "default_value", text=k)
            elif source_node.bl_idname == 'ShaderNodeMapRange':
                col.prop(source_node.inputs['To Min'], "default_value", text="Output Min")
                col.prop(source_node.inputs['To Max'], "default_value", text="Output Max")
        
        if input_name == 'Normal' and source_node.type in {'NORMAL_MAP', 'BUMP'}:
            row_norm = layout.row()
            row_norm.alignment = 'RIGHT'
            row_norm.prop(source_node.inputs['Strength'], "default_value", text="Strength", slider=True)

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        
        if obj and obj.material_slots and obj.material_slots[0].link == 'OBJECT':
            mat_name = obj.material_slots[0].material.name if obj.material_slots[0].material else ""
            if "Studio_Wire" in mat_name or "AO_" in mat_name:
                layout.label(text="Disable Wireframe/AO first!", icon='ERROR')
                return

        if not obj or not obj.active_material:
            layout.label(text="Select Object with Material", icon='INFO')
            return

        mat = obj.active_material
        bsdf = get_principled(mat)
        out = get_output_node(mat)
        
        if not bsdf:
            layout.label(text="No Principled BSDF", icon='ERROR')
            return

        if obj.material_slots[0].link == 'OBJECT':
            row = layout.row()
            row.alignment = 'RIGHT'
            row.operator("mattools.restore_original", text="Restore Original", icon='FILE_REFRESH')

        if out and out.inputs['Surface'].links and out.inputs['Surface'].links[0].from_node != bsdf:
             box = layout.box()
             box.alert = True
             box.label(text="SOLO MODE ACTIVE", icon='VIEWZOOM')
        
        box = layout.box()
        box.label(text="Surface", icon='MATERIAL')
        col = box.column()
        self.draw_socket_row(col, bsdf, out, 'Base Color')
        col.separator()
        self.draw_socket_row(col, bsdf, out, 'Metallic')
        self.draw_socket_row(col, bsdf, out, 'Roughness')
        
        if 'Specular IOR Level' in bsdf.inputs: self.draw_socket_row(col, bsdf, out, 'Specular IOR Level', "Specular")
        elif 'Specular' in bsdf.inputs: self.draw_socket_row(col, bsdf, out, 'Specular')

        box = layout.box()
        box.label(text="Geometry", icon='OUTLINER_DATA_MESH')
        self.draw_socket_row(box, bsdf, out, 'Normal')

        box = layout.box()
        r = box.row()
        r.label(text="Emission", icon='LIGHT_SUN')
        r.operator("mattools.link_emission", text="Link Base", icon='LINKED')
        c = box.column()
        self.draw_socket_row(c, bsdf, out, 'Emission Color')
        c.prop(bsdf.inputs['Emission Strength'], "default_value", text="Strength")

class STUDIO_PT_SSS(bpy.types.Panel):
    bl_label = "Skin & Subsurface"
    bl_idname = "STUDIO_PT_sss"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Asset Stage"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.sss_props
        obj = context.active_object
        
        if not obj or not obj.active_material:
            layout.label(text="Select Object", icon='INFO')
            return

        is_tweaked = (obj.material_slots[0].link == 'OBJECT')

        if not is_tweaked:
            layout.label(text="Apply SSS Preset:", icon='MATCLOTH')
            grid = layout.grid_flow(row_major=True, columns=2, align=True)
            grid.operator("sss.set_preset", text="Human").mode = 'HUMAN'
            grid.operator("sss.set_preset", text="Alien").mode = 'ALIEN'
            grid.operator("sss.set_preset", text="Marble").mode = 'MARBLE'
            grid.operator("sss.set_preset", text="Avatar").mode = 'BLUE'
            
            layout.separator()
            layout.operator("sss.init", text="Initialize Manual SSS", icon='SHADING_RENDERED')

        else:
            row = layout.row()
            row.label(text="Mode: Unique SSS", icon='PINNED')
            row.operator("sss.restore", text="Restore Original", icon='FILE_REFRESH')
            
            box = layout.box()
            box.label(text="Physics", icon='PHYSICS')
            col = box.column(align=True)
            col.prop(props, "sss_scale")
            col.prop(props, "sss_radius_color")
            
            layout.separator()
            layout.label(text="Quick Presets:")
            
            grid = layout.grid_flow(row_major=True, columns=2, align=True)
            grid.operator("sss.set_preset", text="Human").mode = 'HUMAN'
            grid.operator("sss.set_preset", text="Alien").mode = 'ALIEN'
            grid.operator("sss.set_preset", text="Marble").mode = 'MARBLE'
            grid.operator("sss.set_preset", text="Avatar").mode = 'BLUE'

class STUDIO_PT_WireframePanel(bpy.types.Panel):
    bl_label = "Wireframe"
    bl_idname = "STUDIO_PT_wireframe"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Asset Stage"
    bl_options = {'DEFAULT_CLOSED'}       
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.studio_tool_props
        obj = context.active_object
        
        is_wire_mode = False
        is_unique = False
        
        if obj and obj.type == 'MESH' and obj.material_slots:
            slot = obj.material_slots[0]
            if slot.link == 'OBJECT' and slot.material and "Studio_Wireframe" in slot.material.name:
                is_wire_mode = True
                if "Unique" in slot.material.name:
                    is_unique = True
        
        if is_wire_mode:
            box = layout.box()
            row = box.row()
            if is_unique:
                row.label(text="Mode: Unique", icon='UNLINKED')
            else:
                row.label(text="Mode: Overlay", icon='MOD_WIREFRAME')
                
            row = box.row(align=True)
            row.operator("tools.restore_wireframe", text="Restore", icon='FILE_REFRESH')
            
            if is_unique:
                row.operator("tools.link_wire_global", text="Link Global", icon='LINKED')
            else:
                row.operator("tools.make_wire_unique", text="Unique", icon='UNLINKED')
        
        else:
            row = layout.row(align=True)
            row.scale_y = 1.2
            op = row.operator("tools.apply_wireframe_smart", text="Dark / Cyan", icon='SHADING_WIRE')
            op.style = 'DARK'
            op = row.operator("tools.apply_wireframe_smart", text="White / Black", icon='SHADING_RENDERED')
            op.style = 'LIGHT'

        layout.separator()
        layout.label(text="Settings:", icon='PREFERENCES')
        col = layout.column(align=True)
        col.prop(props, "wire_base_col")
        col.prop(props, "wire_line_col") 
        col.separator()
        col.prop(props, "wire_thick", slider=True)
        
        if not is_wire_mode:
            sub = col.row()
            sub.scale_y = 1.4
            op = sub.operator("tools.apply_wireframe_smart", text="Apply Custom", icon='BRUSH_DATA')
            op.style = 'CUSTOM'

class STUDIO_PT_WeatheringPanel(bpy.types.Panel):
    bl_label = "Wearing"
    bl_idname = "STUDIO_PT_weathering"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Asset Stage"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.weathering_props
        obj = context.active_object
        
        if not obj or not obj.active_material:
            layout.label(text="Select Object", icon='INFO')
            return

        is_active = False
        if obj.active_material.node_tree:
            for n in obj.active_material.node_tree.nodes:
                if n.type == 'GROUP' and n.node_tree and "Pro_Weathering_FX" in n.node_tree.name:
                    is_active = True
                    break
        
        row = layout.row(align=True)
        if is_active:
            row.label(text="Status: Active", icon='BRUSH_DATA')
            row.operator("weather.remove", text="Disable", icon='X')
        else:
            row.operator("weather.apply", text="Enable Weathering", icon='ADD')
            return 

        layout.separator()
        
        col = layout.column(align=True)
        col.prop(props, "w_global_scale", text="Global Scale")
        
        layout.separator()

        box = layout.box()
        box.label(text="Breakup & Patches", icon='TEXTURE')
        col = box.column(align=True)
        col.prop(props, "w_breakup_cov")
        col.prop(props, "w_breakup_scale")
        col.prop(props, "w_breakup_cont")

        box = layout.box()
        box.label(text="Dirt Accumulation", icon='MATFLUID')
        col = box.column(align=True)
        col.prop(props, "w_dirt_color", text="")
        col.prop(props, "w_dirt_amount")
        col.prop(props, "w_dirt_spread")
        col.prop(props, "w_dirt_texture")

        box = layout.box()
        box.label(text="Edge Wear", icon='EDGESEL')
        col = box.column(align=True)
        col.prop(props, "w_edge_amount")
        col.prop(props, "w_edge_sense")
        
        layout.separator()
        layout.prop(props, "w_bump_val", slider=True, icon='NORMAL_MAP')

class STUDIO_PT_AOPanel(bpy.types.Panel):
    bl_label = "Ambient Occlusion"
    bl_idname = "STUDIO_PT_ao"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Asset Stage"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.ao_tools_props
        obj = context.active_object

        is_clay_mode = False
        is_unique = False
        
        if obj and obj.type == 'MESH' and obj.material_slots:
            slot = obj.material_slots[0]
            if slot.link == 'OBJECT' and slot.material:
                is_clay_mode = True
                if slot.material.name != AO_MAT_NAME:
                    is_unique = True

        if is_clay_mode:
            box = layout.box()
            row = box.row()
            if is_unique:
                row.label(text="Mode: Unique", icon='UNLINKED')
            else:
                row.label(text="Mode: Global", icon='WORLD')
            
            row = box.row(align=True)
            row.operator("ao.restore_original", text="Restore", icon='FILE_REFRESH')
            
            if is_unique:
                row.operator("ao.relink_global", text="Link Global", icon='LINKED')
            else:
                row.operator("ao.make_unique", text="Unique", icon='UNLINKED')

        else:
            layout.operator("ao.apply_shader", text="Apply Clay Mode", icon='SHADING_RENDERED')

        layout.separator()
        layout.label(text="Presets:")
        
        grid = layout.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=True)
        grid.operator("ao.reset_grey", text="Grey Clay")
        grid.operator("ao.preset_redwax", text="Red Wax")
        row = layout.row()
        row.operator("ao.preset_beige", text="Beige Sculpey")

        layout.separator()
        layout.label(text="Tweaks (Active Object):")

        col = layout.column(align=True)
        col.prop(props, "color_surface")
        col.prop(props, "color_crevice")
        col.separator()
        col.prop(props, "ao_distance")
        col.prop(props, "ao_contrast")
        col.prop(props, "roughness")
        col.prop(props, "ao_inside")

class STUDIO_PT_RenderingPanel(bpy.types.Panel):
    bl_label = "Rendering"
    bl_idname = "STUDIO_PT_rendering"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Asset Stage"
    bl_options = {'DEFAULT_CLOSED'} 

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        space = context.space_data
        props = scene.studio_tool_props 
        
        if space.type == 'VIEW_3D':
            layout.label(text="Viewport Mode:")
            row = layout.row(align=True)
            row.scale_y = 1.3
            row.prop_enum(space.shading, "type", "MATERIAL", text="Preview", icon='SHADING_TEXTURE')
            row.prop_enum(space.shading, "type", "RENDERED", text="Render", icon='SHADING_RENDERED')
        
        layout.separator()

        layout.label(text="Output Quality:")
        box = layout.box()
        col = box.column(align=True)
        
        row = col.row()
        row.prop(props, "aspect_ratio", text="Ratio")
        row.prop(props, "lock_aspect_ratio", text="", icon='LOCKED' if props.lock_aspect_ratio else 'UNLOCKED')
        
        col.separator()

        row = col.row(align=True)
        row.scale_y = 1.3
        row.prop_enum(props, "quality_mode", "SD")
        row.prop_enum(props, "quality_mode", "HD")
        row.prop_enum(props, "quality_mode", "4K")
        row.prop_enum(props, "quality_mode", "8K")
        row.prop_enum(props, "quality_mode", "CUSTOM", icon='GREASEPENCIL')
        
        col.separator()
        
        if props.quality_mode == 'CUSTOM':
            row = col.row(align=True)
            row.prop(props, "res_x", text="Width")
            row.prop(props, "res_y", text="Height")
        else:
            final_x = int(scene.render.resolution_x * (scene.render.resolution_percentage / 100))
            final_y = int(scene.render.resolution_y * (scene.render.resolution_percentage / 100))
            
            box_res = col.box()
            box_res.scale_y = 0.8
            row = box_res.row()
            row.alignment = 'CENTER'
            row.label(text=f"Output Size: {final_x} x {final_y} px", icon='CHECKMARK')

        layout.separator()

        layout.label(text="Output Destination:")
        box = layout.box()
        box.prop(props, "save_destination", text="")
        
        if props.save_destination == 'CUSTOM':
            box.prop(props, "root_path", text="") 
        elif props.save_destination == 'RELATIVE':
            if not bpy.data.filepath:
                box.alert = True
                box.label(text="File unsaved! Please save first.", icon='ERROR')
            else:
                box.label(text="Saving to: //Renders/...", icon='FILE_FOLDER')
        elif props.save_destination == 'DESKTOP':
            box.label(text="Saving to: Desktop/...", icon='DESKTOP')

        layout.separator()

        layout.label(text="Include in Name:")
        grid = layout.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=True)
        grid.prop(props, "use_date")
        grid.prop(props, "use_filename")
        grid.prop(props, "use_scene")
        grid.prop(props, "use_camera")
        
        row = layout.row()
        row.prop(props, "use_custom")
        if props.use_custom:
            row = layout.row()
            row.prop(props, "custom_text", text="")
        
        layout.separator()
        
        base_name = generate_render_filename(scene, props)
        ext = "png"
        if props.file_format == 'JPEG': ext = "jpg"
        elif props.file_format == 'OPEN_EXR': ext = "exr"
        
        prev_box = layout.box()
        prev_box.label(text="Folder Structure Preview:")
        col = prev_box.column()
        col.label(text=f"📂 {base_name}/")
        col.label(text=f"  └─ 🖼️ {base_name}_####.{ext}")
        
        layout.separator()
        
        layout.prop(props, "file_format", text="File Type")
        
        col = layout.column(align=True)
        col.scale_y = 1.5
        col.operator("studio.render_still", text="Render Image") 
        col.operator("studio.render_anim", text="Render Animation")


class STUDIO_PT_ToolboxPanel(bpy.types.Panel):
    """Parent Panel - Compositing Helpers"""
    bl_label = "Compositing Helpers"
    bl_idname = "STUDIO_PT_toolbox"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Asset Stage"
    bl_options = {'DEFAULT_CLOSED'}

    def _is_ghost_mode_active(self, context):
        """Checks if ANY Ghost Mode nodes exist so we can offer to clean them up."""
        scene = context.scene
        if not scene.use_nodes: return False
        
        tree = None
        if hasattr(scene, "compositing_node_group") and scene.compositing_node_group:
            tree = scene.compositing_node_group
        elif hasattr(scene, "node_tree"):
            tree = scene.node_tree
        
        if not tree: return False

        for n in tree.nodes:
            if n.type == 'ID_MASK':
                return True
                
        return False

    def _are_any_selected_shadow_catchers(self, context):
        for obj in context.selected_objects:
            if getattr(obj, "is_shadow_catcher", False): return True
        return False

    def _are_any_selected_invisible(self, context):
        for obj in context.selected_objects:
            if not obj.visible_camera: return True
        return False

    def _are_any_selected_ghosts(self, context):
        """Checks if selected objects have the magic number (99)"""
        target_idx = context.scene.studio_tool_props.ghost_index
        for obj in context.selected_objects:
            if obj.pass_index == target_idx:
                return True
        return False

    def draw(self, context):
        layout = self.layout
        props = context.scene.studio_tool_props 

        row = layout.row()
        row.prop(context.scene.render, "film_transparent", toggle=True, text="Transparent Background")

        layout.separator()

        box = layout.box()
        box.label(text="Primary Visibility Flags")
        row = box.row(align=True)
        row.scale_y = 1.2
        row.operator("tools.make_invisible", text="Disable Primary Vis")
        if self._are_any_selected_invisible(context):
            row.operator("tools.restore_visibility", text="Enable Primary Vis")

        layout.separator()

        box = layout.box()
        box.label(text="Shadow Catcher")
        col = box.column(align=True)
        col.scale_y = 1.2
        col.operator("tools.make_shadow_catcher", text="Turn On Shadow Catcher")
        if self._are_any_selected_shadow_catchers(context):
            col.operator("tools.restore_shadow_catcher", text="Turn Off Shadow Catcher")

        layout.separator()

        box = layout.box()
        box.label(text="Compositor / AOVs")
        
        row = box.row()
        row.prop(props, "ghost_index")

        col = box.column(align=True)
        col.scale_y = 1.2
        
        if self._are_any_selected_ghosts(context):
            col.operator("tools.exclude_ghost", text="Clear Object ID")
        else:
            col.operator("tools.apply_ghost", text="Generate ID Matte")

        if self._is_ghost_mode_active(context):
            col.separator()
            col.operator("tools.remove_ghost", text="Reset Nodetree")


# ==============================================================================
#   REGISTRATION
# ==============================================================================

classes = (
    StudioMasterProps,
    AO_Properties,
    SSS_Properties,
    Weathering_Properties,
    WEATHER_OT_Apply,    
    WEATHER_OT_Remove,    
    STUDIO_OT_RunSetup,
    OBJECT_OT_ReverseTurntableDirection,
    OBJECT_OT_RemoveTurntable,
    OBJECT_OT_AddTurntableDriver,
    OBJECT_OT_SyncTurntableRange,
    RENDER_OT_OpenOutputFolder,
    TOOLS_OT_ApplyWireframeSmart,
    TOOLS_OT_RestoreWireframe,
    TOOLS_OT_MakeWireUnique,
    TOOLS_OT_LinkWireGlobal,
    AO_OT_ApplyShader,
    AO_OT_RestoreOriginal,
    AO_OT_MakeUnique,
    AO_OT_RelinkGlobal,
    AO_OT_ResetGrey,
    AO_OT_RedWax,
    AO_OT_BeigeSculpey,
    MATTOOLS_OT_RestoreOriginal,
    MATTOOLS_OT_LinkEmission,
    MATTOOLS_OT_AddControl,
    MATTOOLS_OT_RemoveControl,
    MATTOOLS_OT_ResetControl,
    MATTOOLS_OT_FixColorSpaces,
    MATTOOLS_OT_SoloInput,
    SSS_OT_Init,
    SSS_OT_Restore,
    SSS_OT_Preset,
    TOOLS_OT_MakeInvisible,
    TOOLS_OT_RestoreVisibility,
    TOOLS_OT_MakeShadowCatcher, 
    TOOLS_OT_RestoreShadowCatcher, 
    STUDIO_OT_SmartStill,
    STUDIO_OT_SmartAnim,
    STUDIO_PT_MainPanel,
    STUDIO_PT_TurntablePanel,
    STUDIO_PT_MaterialPanel,  
    STUDIO_PT_SSS,
    STUDIO_PT_WireframePanel,
    STUDIO_PT_AOPanel,
    STUDIO_PT_WeatheringPanel, 
    STUDIO_PT_RenderingPanel,
    STUDIO_PT_ToolboxPanel,    
    TOOLS_OT_ApplyGhost,  
    TOOLS_OT_RemoveGhost,
    TOOLS_OT_ExcludeGhost,   

)

def register():
    if hasattr(bpy.types.Scene, "studio_tool_props"):
        del bpy.types.Scene.studio_tool_props
    if hasattr(bpy.types.Scene, "ao_tools_props"):
        del bpy.types.Scene.ao_tools_props
        
    for cls in classes:
        try: bpy.utils.register_class(cls)
        except ValueError: pass
        
    bpy.types.Scene.studio_tool_props = bpy.props.PointerProperty(type=StudioMasterProps)
    bpy.types.Scene.ao_tools_props = bpy.props.PointerProperty(type=AO_Properties)
    bpy.types.Scene.sss_props = bpy.props.PointerProperty(type=SSS_Properties)
    bpy.types.Scene.weathering_props = bpy.props.PointerProperty(type=Weathering_Properties)

def unregister():
    for cls in reversed(classes):
        try: bpy.utils.unregister_class(cls)
        except: pass
        
    if hasattr(bpy.types.Scene, "studio_tool_props"):
        del bpy.types.Scene.studio_tool_props
    if hasattr(bpy.types.Scene, "sss_props"):
        del bpy.types.Scene.sss_props
    if hasattr(bpy.types.Scene, "ao_tools_props"):
        del bpy.types.Scene.ao_tools_props
    if hasattr(bpy.types.Scene, "weathering_props"):
        del bpy.types.Scene.weathering_props

if __name__ == "__main__":
    register()